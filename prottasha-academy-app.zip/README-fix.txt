FIX: Android app support chat + calling stuck on "connecting"

Cause: backend/chat/hub.js sameOrigin() only accepted WebSocket origins equal to the website host. The Android app runs from
https://localhost, so /chat-ws and /call-ws returned 403 before the app could even say hello.

Files (same paths as in your project - copy over the originals, do NOT touch .env):
  backend/chat/hub.js        sameOrigin() now accepts the app origins, student/visitor sockets only
  backend/calling/hub.js     /call-ws passes allowApp (admin socket stays strict)
  test/app-origin.test.js    new regression test   ->  npm run test:app-origin
  package.json               adds the test:app-origin script (only change)

After copying: restart the Node app on your host.
