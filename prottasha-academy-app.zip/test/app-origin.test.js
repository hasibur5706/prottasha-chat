// The installed mobile app (Capacitor WebView) connects from the origin https://localhost, not from the website's own host.
//   node test/app-origin.test.js     (needs the `ws` package; no browser, no database, no network)
const assert = require('assert');
const http = require('http');
const crypto = require('crypto');
const WebSocket = require('ws');
process.removeAllListeners('warning');

const adminAuth = require('../backend/admin/admin-auth');
adminAuth.resolve = async req => (req.headers['x-agent'] ? { username: String(req.headers['x-agent']), can: () => true } : null);

const b64 = o => Buffer.from(JSON.stringify(o)).toString('base64url');
function jwt(user) {
  const head = b64({ alg: 'HS256', typ: 'JWT' }), body = b64({ ...user, exp: Math.floor(Date.now() / 1000) + 3600 });
  const sig = crypto.createHmac('sha256', process.env.JWT_SECRET || 'fallback_secret_change_me').update(head + '.' + body).digest('base64url');
  return head + '.' + body + '.' + sig;
}

let server, chatHub, callHub, port;
// resolves with the first message the server sends after "hello" (or the HTTP status if the handshake is refused)
function probe(path, headers, hello) {
  return new Promise(resolve => {
    const ws = new WebSocket('ws://127.0.0.1:' + port + path, { headers });
    const done = r => { try { ws.terminate(); } catch (e) { /* closed */ } resolve(r); };
    ws.on('unexpected-response', (req, res) => done({ rejected: res.statusCode }));
    ws.on('error', () => {});
    ws.on('open', () => { if (hello) ws.send(JSON.stringify(hello)); else setTimeout(() => done({ opened: true }), 400); });   // no hello: the admin sockets send "init" by themselves
    ws.on('message', raw => { const m = JSON.parse(raw.toString()); if (m.t === 'ready' || m.t === 'init') done({ opened: true, first: m.t }); });
    setTimeout(() => done({ timeout: true }), 2500);
  });
}

const APP = { origin: 'https://localhost' }, IOS = { origin: 'capacitor://localhost' }, EVIL = { origin: 'https://evil.example' };
const tests = [];
const test = (n, f) => tests.push([n, f]);

test('mobile app origin can open the student call socket and get "ready"', async () => {
  for (const h of [APP, IOS]) assert.deepStrictEqual(await probe('/call-ws', h, { t: 'hello', token: jwt({ id: 5, name: 'App' }) }), { opened: true, first: 'ready' });
});
test('mobile app origin can open the chat socket and get "ready"', async () => {
  for (const h of [APP, IOS]) assert.deepStrictEqual(await probe('/chat-ws', h, { t: 'hello', visitorId: 'a'.repeat(32), token: jwt({ id: 5, name: 'App' }) }), { opened: true, first: 'ready' });
});
test('a foreign website origin is still refused (403) on both student sockets', async () => {
  assert.deepStrictEqual(await probe('/call-ws', EVIL), { rejected: 403 });
  assert.deepStrictEqual(await probe('/chat-ws', EVIL), { rejected: 403 });
});
test('the app origin is NOT accepted on the cookie-authenticated admin sockets', async () => {
  assert.deepStrictEqual(await probe('/admin/call-ws', { ...APP, 'x-agent': 'Rafi' }), { rejected: 403 });
  assert.deepStrictEqual(await probe('/admin/chat-ws', { ...APP, 'x-agent': 'Rafi' }), { rejected: 403 });
});
test('same-site browsers and non-browser clients keep working (student + admin)', async () => {
  assert.strictEqual((await probe('/call-ws', { origin: 'http://127.0.0.1:' + port }, { t: 'hello', token: jwt({ id: 6, name: 'Web' }) })).first, 'ready');
  assert.strictEqual((await probe('/call-ws', {}, { t: 'hello', token: jwt({ id: 7, name: 'Curl' }) })).first, 'ready');
  assert.strictEqual((await probe('/admin/call-ws', { origin: 'http://127.0.0.1:' + port, 'x-agent': 'Rafi' })).first, 'init');
});

(async () => {
  server = http.createServer((q, r) => r.end('ok'));
  chatHub = require('../backend/chat/hub').attach(server);
  callHub = require('../backend/calling/hub').attach(server);
  await new Promise(r => server.listen(0, '127.0.0.1', r)); port = server.address().port;
  let passed = 0, failed = 0;
  for (const [name, fn] of tests) {
    try { await fn(); passed++; console.log('  ok   ' + name); }
    catch (e) { failed++; console.log('  FAIL ' + name + '\n       ' + (e && e.stack || e).toString().split('\n').slice(0, 4).join('\n       ')); }
  }
  console.log(`\n${passed} passed, ${failed} failed`);
  try { chatHub.close && chatHub.close(); callHub.close && callHub.close(); } catch (e) { /* ignore */ }
  server.close(); process.exit(failed ? 1 : 0);
})();
