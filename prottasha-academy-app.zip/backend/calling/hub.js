// Voice / video calls from the support team (admin panel) to a logged-in student, over WebRTC.
// This file is only the "switchboard": it rings the student, relays the WebRTC handshake between the two browsers
// and records the call. The audio / video itself flows directly browser-to-browser (or through your TURN server).
//
//   /admin/call-ws   support team   - same signed `admin_session` cookie as the admin panel, needs the "Live chat" module (edit)
//   /call-ws         students       - the student login token (JWT), sent in the first frame
//
// Usage (server.js):
//   const calls = require('./backend/calling/hub').attach(httpServer);
//   calls.useDatabase(db);      // once MySQL is connected: keeps the call history in the call_logs table
//
// Calls go both ways: the support team can ring a student (dir 'out'), and a logged-in student can ring the support team
// from the chat window (dir 'in'). A student's call rings only the admins who are NOT already in a chat or on a call (or just the
// admin who is already handling that student); the first one to accept takes the call and becomes the student's agent.
//
// Wire protocol: JSON text frames with a `t` (type). See handleAdmin / handleStudent below.
const crypto = require('crypto');
const { WebSocketServer } = require('ws');
const { verifyJwt, sameOrigin, clientIp } = require('../chat/hub');
const logs = require('./logs');
const agents = require('../support/agents');     // which admin is free / busy and who handles which student (shared with the chat hub)

const RING_MS = 45000;
const MAX_FRAME = 64 * 1024;            // an SDP offer is a few KB
const HEARTBEAT_MS = 30000;
const MAX_SOCKETS_PER_IP = 20;
const STUDENT_CALLS_PER_10MIN = 6;
const ADMIN_CALLS_PER_MIN = 20;
const ADMIN_NAME = () => (process.env.CHAT_ADMIN_NAME || 'Support').slice(0, 40);

function iceServers() {
  const list = [{ urls: 'stun:stun.l.google.com:19302' }];
  const urls = (process.env.CALL_TURN_URL || '').split(',').map(s => s.trim()).filter(Boolean);
  if (urls.length) list.push({ urls, username: process.env.CALL_TURN_USERNAME || '', credential: process.env.CALL_TURN_CREDENTIAL || '' });
  return list;
}

const cleanNote = s => String(s == null ? '' : s).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim().slice(0, 2000);

function attach(server) {
  let db = null;
  const wss = new WebSocketServer({ noServer: true, maxPayload: MAX_FRAME });
  const students = new Map();           // userId -> { name, sockets:Set<ws> }
  const admins = new Set();             // Set<ws>
  const calls = new Map();              // callId -> call
  const busyStudents = new Map();       // userId -> callId
  const ipSockets = new Map();
  const studentCallTimes = new Map();   // userId -> timestamps of the calls this student started (rate limit)

  const send = (ws, payload) => { if (ws && ws.readyState === 1) ws.send(JSON.stringify(payload)); };
  const toAdmins = payload => { for (const a of admins) send(a, payload); };
  const toRing = (call, payload) => { for (const a of call.ringTo || []) send(a, payload); };       // only the admins this student's call was offered to
  const toStudent = (userId, payload, except) => { const s = students.get(userId); if (s) for (const w of s.sockets) if (w !== except) send(w, payload); };
  const presenceOf = userId => ({ t: 'presence', userId, online: students.has(userId), busy: busyStudents.has(userId), name: (students.get(userId) || {}).name || '' });
  const safeLog = fn => Promise.resolve().then(fn).catch(err => console.error('Calling: log error:', err && err.message ? err.message : err));

  // ---------- ending a call ----------
  function finish(call, status, reason) {
    if (!call || call.finished) return;
    call.finished = true;
    clearTimeout(call.ringTimer);
    calls.delete(call.id);
    busyStudents.delete(call.userId);
    if (call.adminWs && call.adminWs.callId === call.id) call.adminWs.callId = null;
    if (call.adminWs && call.adminWs.agentKey) {
      agents.callEnd(call.adminWs.agentKey, call.id);                                  // this admin can be notified again
      if (call.dir === 'in') agents.expireSoon('u' + call.userId, call.adminWs.agentKey);   // ...and is not tied to that student for long after a quick call
    }
    const endedMs = Date.now();
    const duration = call.answeredMs ? Math.round((endedMs - call.answeredMs) / 1000) : 0;
    safeLog(() => logs.finish(call.id, { status, reason, endedMs, duration }));
    const ev = { t: 'ended', callId: call.id, status, reason: reason || '', duration };
    send(call.adminWs, ev);
    toStudent(call.userId, ev);
    if (call.dir === 'in' && !call.adminWs) toRing(call, { t: 'incoming-gone', callId: call.id });   // nobody took it: stop every ring
    toAdmins(presenceOf(call.userId));
  }

  // ---------- admin side ----------
  async function handleAdmin(ws, msg) {
    switch (msg.t) {
      case 'call': {
        const tmp = String(msg.tmp || '').slice(0, 40);
        const fail = error => send(ws, { t: 'call-error', tmp, error });
        const userId = Number(msg.userId);
        if (!Number.isInteger(userId) || userId <= 0) return fail('Invalid student.');
        const now = Date.now();
        ws.callTimes = (ws.callTimes || []).filter(x => now - x < 60000);
        if (ws.callTimes.length >= ADMIN_CALLS_PER_MIN) return fail('Too many calls. Please wait a minute.');
        if (ws.callId) return fail('You are already on a call.');
        const stu = students.get(userId);
        if (!stu) return fail('This student is not online on the site right now.');
        if (busyStudents.has(userId)) return fail('This student is already on a call.');
        ws.callTimes.push(now);

        const call = { id: crypto.randomUUID(), dir: 'out', adminWs: ws, adminName: ws.adminName, userId, studentName: stu.name, studentWs: null, agentName: ws.agentName,
          video: !!msg.video, startedMs: now, answeredMs: null, finished: false, ringTimer: null };
        calls.set(call.id, call); ws.callId = call.id; busyStudents.set(userId, call.id);
        agents.callStart(ws.agentKey, call.id);
        safeLog(() => logs.create({ callId: call.id, userId, studentName: stu.name, adminName: ws.adminName, video: call.video, startedMs: now, direction: 'out' }));
        call.ringTimer = setTimeout(() => finish(call, 'missed', 'no answer'), RING_MS);
        toStudent(userId, { t: 'incoming', callId: call.id, from: ws.agentName || ADMIN_NAME(), video: call.video });
        send(ws, { t: 'call-started', tmp, callId: call.id, userId, name: stu.name, video: call.video });
        toAdmins(presenceOf(userId));
        return;
      }
      case 'accept': {                 // an agent picks up a call that a student started
        const call = calls.get(String(msg.callId));
        if (!call || call.dir !== 'in' || call.answeredMs || call.adminWs || !call.ringTo.has(ws)) return send(ws, { t: 'incoming-gone', callId: String(msg.callId || '') });
        if (ws.callId) return send(ws, { t: 'incoming-gone', callId: call.id, error: 'You are already on a call.' });
        clearTimeout(call.ringTimer);
        call.adminWs = ws; call.adminName = ws.adminName; call.agentName = ws.agentName; call.answeredMs = Date.now(); ws.callId = call.id;
        safeLog(() => logs.answered(call.id, call.answeredMs, ws.adminName));
        agents.callStart(ws.agentKey, call.id);
        for (const a of call.ringTo) if (a !== ws) send(a, { t: 'incoming-gone', callId: call.id, takenBy: ws.agentName });   // stop the ring on the other agents
        send(call.studentWs, { t: 'accepted', callId: call.id, agent: ws.agentName });                                       // the student (the caller) now sends the offer
        agents.claim('u' + call.userId, { key: ws.agentKey, name: ws.agentName }, null);                                     // this admin is now the student's agent: their name shows in the student's chat
        return;
      }
      case 'decline': {                // this agent says no; the student keeps ringing until every online agent has said no
        const call = calls.get(String(msg.callId));
        if (!call || call.dir !== 'in' || call.answeredMs || call.adminWs) return;
        if (!call.ringTo.has(ws)) return;
        call.declined.add(ws);
        if ([...call.ringTo].every(a => call.declined.has(a) || a.readyState !== 1)) finish(call, 'declined', 'support is busy');
        return;
      }
      case 'end': {
        const call = calls.get(String(msg.callId));
        if (!call || call.adminWs !== ws) return;
        return finish(call, call.answeredMs ? 'completed' : 'cancelled');
      }
      case 'signal': {
        const call = calls.get(String(msg.callId));
        if (!call || call.adminWs !== ws || !call.studentWs || !msg.data) return;
        return send(call.studentWs, { t: 'signal', callId: call.id, data: msg.data });
      }
      case 'note': {
        const ok = await logs.setNote(String(msg.callId), ws.adminName, cleanNote(msg.note));
        return send(ws, { t: 'note-saved', callId: String(msg.callId), ok: !!ok });
      }
      default: return;
    }
  }

  // ---------- student side ----------
  async function onStudentHello(ws, msg) {
    const user = msg.token ? verifyJwt(msg.token) : null;
    if (!user || !user.id) return send(ws, { t: 'error', text: 'Please log in again.' });
    const userId = Number(user.id);
    let name = String(user.name || '').slice(0, 60) || 'Student';
    if (db) {
      try {
        const row = await db.prepare('SELECT name FROM users WHERE id = ?').get(userId);
        if (!row) return send(ws, { t: 'error', text: 'Please log in again.' });
        name = String(row.name || name).slice(0, 60);
      } catch (e) { /* keep the name from the token */ }
    }
    if (ws.userId && ws.userId !== userId) unbindStudent(ws);
    if (!ws.userId) {
      ws.userId = userId;
      const entry = students.get(userId) || { name, sockets: new Set() };
      entry.name = name; entry.sockets.add(ws); students.set(userId, entry);
    }
    send(ws, { t: 'ready', iceServers: iceServers() });
    toAdmins(presenceOf(userId));
    // a call that started ringing while this tab was reconnecting
    const callId = busyStudents.get(userId); const call = callId && calls.get(callId);
    if (call && call.dir === 'out' && !call.answeredMs) send(ws, { t: 'incoming', callId: call.id, from: call.agentName || ADMIN_NAME(), video: call.video });
  }

  function unbindStudent(ws) {
    const userId = ws.userId; if (!userId) return;
    ws.userId = null;
    const entry = students.get(userId);
    if (entry) { entry.sockets.delete(ws); if (!entry.sockets.size) students.delete(userId); }
    const callId = busyStudents.get(userId); const call = callId && calls.get(callId);
    if (call) {
      if (call.studentWs === ws) finish(call, call.answeredMs ? 'completed' : 'cancelled', 'student disconnected');
      else if (!call.answeredMs && call.dir === 'out' && !students.has(userId)) finish(call, 'missed', 'student went offline');
    }
    toAdmins(presenceOf(userId));
  }

  // A student rings the support team from the chat window.
  function studentCall(ws, msg) {
    const tmp = String(msg.tmp || '').slice(0, 40);
    const fail = error => send(ws, { t: 'call-error', tmp, error });          // error is a code; the page shows the text
    const userId = ws.userId;
    const stu = students.get(userId);
    if (!stu) return fail('offline');
    if (!admins.size) return fail('no-agent');
    if (busyStudents.has(userId)) return fail('busy');
    // who rings: the admin already handling this student (unless they are on a call), otherwise every admin who is not in a chat or on a call
    const held = agents.claimOf('u' + userId);
    let exclusiveKey = null;
    let ringTo = held ? [...admins].filter(a => a.agentKey === held.key && !agents.inCall(a.agentKey)) : [];
    if (ringTo.length) exclusiveKey = held.key; else ringTo = [...admins].filter(a => !agents.isBusy(a.agentKey));
    if (!ringTo.length) return fail('all-busy');
    const now = Date.now();
    const times = (studentCallTimes.get(userId) || []).filter(x => now - x < 600000);
    if (times.length >= STUDENT_CALLS_PER_10MIN) return fail('rate');
    times.push(now); studentCallTimes.set(userId, times);

    const call = { id: crypto.randomUUID(), dir: 'in', adminWs: null, adminName: '', userId, studentName: stu.name, studentWs: ws,
      video: !!msg.video, startedMs: now, answeredMs: null, finished: false, ringTimer: null, declined: new Set(), ringTo: new Set(ringTo), exclusiveKey };
    calls.set(call.id, call); busyStudents.set(userId, call.id);
    safeLog(() => logs.create({ callId: call.id, userId, studentName: stu.name, adminName: '', video: call.video, startedMs: now, direction: 'in' }));
    call.ringTimer = setTimeout(() => finish(call, 'missed', 'no answer'), RING_MS);
    send(ws, { t: 'call-started', tmp, callId: call.id, video: call.video });
    toRing(call, { t: 'incoming', callId: call.id, userId, name: stu.name, video: call.video });
    toAdmins(presenceOf(userId));
  }

  async function handleStudent(ws, msg) {
    if (msg.t === 'hello') return onStudentHello(ws, msg);
    if (!ws.userId) return;
    if (msg.t === 'call') return studentCall(ws, msg);
    const call = calls.get(String(msg.callId));
    if (!call || call.userId !== ws.userId) return;
    switch (msg.t) {
      case 'accept': {
        if (call.dir !== 'out' || call.answeredMs) return;
        clearTimeout(call.ringTimer);
        call.answeredMs = Date.now(); call.studentWs = ws;
        safeLog(() => logs.answered(call.id, call.answeredMs));
        toStudent(ws.userId, { t: 'handled', callId: call.id }, ws);       // stop ringing on the student's other tabs
        send(call.adminWs, { t: 'accepted', callId: call.id });
        return;
      }
      case 'decline': {
        if (call.dir !== 'out' || call.answeredMs) return;
        const reason = msg.reason === 'exam' ? 'student is in an exam' : msg.reason === 'busy' ? 'student is busy' : '';
        return finish(call, 'declined', reason);
      }
      case 'end': {
        if (call.studentWs !== ws) return;
        if (call.answeredMs) return finish(call, 'completed');
        return call.dir === 'in' ? finish(call, 'cancelled') : undefined;       // the student hangs up while support is still ringing
      }
      case 'signal': return call.studentWs === ws && msg.data ? send(call.adminWs, { t: 'signal', callId: call.id, data: msg.data }) : undefined;
      default: return;
    }
  }

  // ---------- connections ----------
  wss.on('connection', (ws, req, role, adminInfo) => {
    ws.role = role; ws.ip = clientIp(req); ws.isAlive = true;
    ipSockets.set(ws.ip, (ipSockets.get(ws.ip) || 0) + 1);
    ws.on('pong', () => { ws.isAlive = true; });
    ws.on('error', () => {});
    ws.on('message', (raw, isBinary) => {
      if (isBinary) return;
      let msg; try { msg = JSON.parse(raw.toString()); } catch (e) { return; }
      if (!msg || typeof msg.t !== 'string') return;
      ws.q = (ws.q || Promise.resolve()).then(() => (role === 'admin' ? handleAdmin(ws, msg) : handleStudent(ws, msg)))
        .catch(err => console.error('Calling error:', err && err.message ? err.message : err));
    });
    ws.on('close', () => {
      const n = (ipSockets.get(ws.ip) || 1) - 1;
      if (n <= 0) ipSockets.delete(ws.ip); else ipSockets.set(ws.ip, n);
      if (role === 'admin') {
        admins.delete(ws);
        const call = ws.callId && calls.get(ws.callId);
        if (call) finish(call, call.answeredMs ? 'completed' : 'cancelled', 'admin disconnected');
      } else unbindStudent(ws);
    });

    if (role === 'admin') {
      ws.adminName = adminInfo.name; ws.agentKey = adminInfo.agentKey; ws.agentName = adminInfo.agentName;
      admins.add(ws);
      const online = [...students.entries()].map(([userId, s]) => ({ userId, name: s.name, busy: busyStudents.has(userId) }));
      const ringing = [...calls.values()].filter(c => c.dir === 'in' && !c.answeredMs && !c.adminWs)
        .filter(c => { if (c.ringTo.has(ws)) return true; const ok = c.exclusiveKey ? ws.agentKey === c.exclusiveKey : !agents.isBusy(ws.agentKey); if (ok) c.ringTo.add(ws); return ok; })   // (an admin who reloads the page keeps their ring)
        .map(c => ({ callId: c.id, userId: c.userId, name: c.studentName, video: c.video }));
      send(ws, { t: 'init', iceServers: iceServers(), online, ringing });
    }
  });

  server.on('upgrade', (req, socket, head) => {
    let pathname;
    try { pathname = new URL(req.url, 'http://internal').pathname; } catch (e) { return; }
    if (pathname !== '/call-ws' && pathname !== '/admin/call-ws') return;       // not ours (the chat hub handles /chat-ws)
    const reject = (code, text) => { try { socket.write(`HTTP/1.1 ${code} ${text}\r\nConnection: close\r\nContent-Length: 0\r\n\r\n`); } catch (e) { /* ignore */ } socket.destroy(); };
    if (!sameOrigin(req, { allowApp: pathname === '/call-ws' })) return reject(403, 'Forbidden');   // the mobile app connects from https://localhost (students only)
    const role = pathname === '/admin/call-ws' ? 'admin' : 'student';
    const open = info => {
      if ((ipSockets.get(clientIp(req)) || 0) >= MAX_SOCKETS_PER_IP) return reject(429, 'Too Many Requests');
      wss.handleUpgrade(req, socket, head, ws => wss.emit('connection', ws, req, role, info));
    };
    if (role !== 'admin') return open();
    require('../admin/admin-auth').resolve(req).then(a => {
      if (!a || a.restricted || !a.can({ mods: ['chat'], level: 'edit' })) return reject(401, 'Unauthorized');
      const who = agents.identify(a);
      open({ name: String(a.username || a.name || 'admin').slice(0, 80), agentKey: who.key, agentName: who.name });
    }).catch(() => reject(500, 'Server Error'));
  });

  const heartbeat = setInterval(() => {
    for (const ws of wss.clients) {
      if (!ws.isAlive) { ws.terminate(); continue; }
      ws.isAlive = false;
      try { ws.ping(); } catch (e) { /* closing */ }
    }
  }, HEARTBEAT_MS);
  heartbeat.unref();
  server.on('close', () => clearInterval(heartbeat));

  return {
    async useDatabase(database) {
      try { await logs.init(database); db = database; console.log('Calling: using MySQL call history.'); }
      catch (err) { console.error('Calling: could not prepare the call_logs table, keeping call history in memory only:', err.message); }
    },
    close() { clearInterval(heartbeat); for (const ws of wss.clients) ws.terminate(); wss.close(); },
    _wss: wss
  };
}

module.exports = { attach };
