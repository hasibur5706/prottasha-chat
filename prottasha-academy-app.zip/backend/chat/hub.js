// Real-time live support chat (WebSocket).
//
//   /chat-ws          visitors: guests (random id kept in the browser) or logged-in students (JWT)
//   /admin/chat-ws    support team: requires the same signed `admin_session` cookie as the admin panel
//
// Usage (server.js):
//   const chat = require('./backend/chat/hub').attach(httpServer);
//   chat.useDatabase(db);            // once MySQL is connected - switches from memory to MySQL storage
//
// Human support: when a student needs a person (the AI hands the chat over, the AI is off, or a person already took over),
// the admins who are NOT already in a chat or on a call get a notification (`notify: true` on the event). The admin who accepts
// the chat (`claim`, or simply replying) becomes the student's agent and the student's chat window shows that admin's name.
//
// Wire protocol: JSON text frames, every frame has a `t` (type). See handleVisitor / handleAdmin below.
const crypto = require('crypto');
const { WebSocketServer } = require('ws');
const core = require('../admin/core');
const { createMemoryStore, createMysqlStore } = require('./store');
const support = require('../support/agent');
const agents = require('../support/agents');      // which admin is free / busy and who handles which student (shared with the calling hub)

const MAX_TEXT = 2000;
const MAX_FRAME = 16 * 1024;
const HEARTBEAT_MS = 30000;
const SEND_BURST = 8;                 // per socket: 8 messages ...
const SEND_WINDOW_MS = 10000;         // ... per 10 seconds
const IP_SEND_PER_MIN = 40;           // per IP across all sockets
const MAX_SOCKETS_PER_IP = 20;
const ADMIN_NAME = () => (process.env.CHAT_ADMIN_NAME || 'Support').slice(0, 40);
const ADMIN_GRACE_MS = () => Number(process.env.SUPPORT_AGENT_GRACE_MS) || 45000;   // an admin who closes the tab keeps their chats this long (page reloads)
const WAITING_MAX_AGE_MS = 30 * 60 * 1000;     // a student who has waited longer than this is no longer announced to an admin who just became free
const AI_RUNS_PER_10MIN = 25;         // AI replies per visitor per 10 minutes (cost control)
const AI_WRITES_PER_HOUR = 10;        // data-changing AI actions per conversation per hour
const AI_PARALLEL = 4;                // AI replies being generated at the same time, site-wide
const AI_TIMEOUT_MS = 75000;
const AI_FALLBACK = 'দুঃখিত, এই মুহূর্তে Prottasha উত্তর দিতে পারছে না। সাপোর্ট টিমকে জানানো হয়েছে — তারা শিগগিরই এখানেই উত্তর দেবে। (Sorry, Prottasha is unavailable right now; the support team has been notified and will reply here.)';
const GUEST_ID_RX = /^[a-f0-9]{32}$/;
const EMAIL_RX = /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,}$/;

// ---------- small helpers ----------
function verifyJwt(token) {
  // Same HS256 tokens the student login issues (jsonwebtoken), verified with plain crypto.
  try {
    const [h, p, s] = String(token).split('.');
    if (!h || !p || !s) return null;
    const secret = process.env.JWT_SECRET || 'fallback_secret_change_me';
    const expected = crypto.createHmac('sha256', secret).update(h + '.' + p).digest();
    const given = Buffer.from(s, 'base64url');
    if (given.length !== expected.length || !crypto.timingSafeEqual(given, expected)) return null;
    if (JSON.parse(Buffer.from(h, 'base64url').toString()).alg !== 'HS256') return null;
    const data = JSON.parse(Buffer.from(p, 'base64url').toString());
    if (data.exp && data.exp < Math.floor(Date.now() / 1000)) return null;
    return data;
  } catch (e) { return null; }
}

const cleanName = s => String(s || '').replace(/[\u0000-\u001f\u007f<>]/g, '').replace(/\s+/g, ' ').trim().slice(0, 60);
const cleanEmail = s => { const e = String(s || '').trim().slice(0, 255); return EMAIL_RX.test(e) ? e : null; };
const cleanText = s => String(s == null ? '' : s).replace(/\r\n/g, '\n').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim().slice(0, MAX_TEXT);
const clientIp = req => (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress || 'unknown';

// Never let the secret visitor key leave the server except back to its owner.
const baseConv = (c, online) => c && ({
  id: c.id, userId: c.userId, name: c.name, email: c.email, status: c.status,
  createdMs: c.createdMs, lastMs: c.lastMs, lastText: c.lastText, lastSender: c.lastSender,
  unread: c.unread, online: !!online,
  aiPaused: !!c.aiPaused, needsHuman: !!c.needsHuman, handoffNote: c.handoffNote || ''
});
const publicMsg = m => m && ({ id: m.id, cid: m.cid, sender: m.sender, adminName: m.adminName, text: m.text, ts: m.ts, readTs: m.readTs });
const publicAction = a => a && ({ id: a.id, cid: a.cid, tool: a.tool, ok: a.ok, summary: a.summary, ts: a.ts });

// chat history -> the plain turns the AI agent reads. Messages written by a human admin are labelled so the AI can tell.
function toAiHistory(messages) {
  const out = messages.map(m => (m.sender === 'visitor'
    ? { role: 'user', text: m.text }
    : { role: 'assistant', text: m.adminName === support.AI_NAME() ? m.text : `[Human support agent ${m.adminName || ''}]: ${m.text}` }));
  while (out.length && out[0].role !== 'user') out.shift();
  return out;
}
const withTimeout = (p, ms) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error('AI reply timed out')), ms).unref())]);

// Origins used by the installed Android / iOS app (Capacitor WebView). The app is served from https://localhost (Android) or
// capacitor://localhost (iOS), so its WebSocket "Origin" never equals the website host.
const APP_ORIGINS = ['https://localhost', 'capacitor://localhost'];

// allowApp: true ONLY for the student / visitor sockets. Those authenticate with a JWT sent in the "hello" message, not with a
// cookie, so accepting the app's origin cannot be abused for cross-site hijacking. The admin sockets (cookie session) keep the
// strict same-site check, so never pass allowApp for them.
function sameOrigin(req, { allowApp = false } = {}) {
  const origin = req.headers.origin;
  if (!origin) return true; // non-browser clients (the cookie / token still has to be valid)
  try {
    const host = String(req.headers['x-forwarded-host'] || req.headers.host || '').split(',')[0].trim().toLowerCase();
    if (new URL(origin).host.toLowerCase() === host) return true;
    if (allowApp && APP_ORIGINS.includes(origin.toLowerCase())) return true;
    const extra = (process.env.CHAT_ALLOWED_ORIGINS || '').split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
    return extra.includes(origin.toLowerCase());
  } catch (e) { return false; }
}

// ---------- the hub ----------
function attach(server) {
  let store = createMemoryStore();
  const wss = new WebSocketServer({ noServer: true, maxPayload: MAX_FRAME });
  const visitors = new Map();           // key -> Set<ws>
  const admins = new Set();             // Set<ws>
  const ipSockets = new Map();          // ip -> open socket count
  const ipSends = new Map();            // ip -> { n, start }
  const aiState = new Map();            // conversation id -> { running, again, userId, key }
  const aiRuns = new Map();             // visitor key -> timestamps of recent AI replies
  const aiWrites = new Map();           // conversation id -> timestamps of recent AI data changes
  const aiLastFallback = new Map();     // conversation id -> when the "AI unavailable" note was last sent
  let aiActive = 0; const aiQueue = [];
  const recentTmp = new Map();          // `${key}:${tmp}` -> { message, at }  (de-duplicates re-sent messages after a reconnect)

  const isOnline = key => !!(visitors.get(key) && visitors.get(key).size);
  const adminOnline = () => admins.size > 0;
  const holderOnline = c => !!c && [...admins].some(a => a.agentKey === c.key);
  // the public view of a conversation, plus which admin is handling it right now
  const publicConv = (c, online) => {
    const o = baseConv(c, online);
    if (o) { const k = agents.claimOf(c.key); o.handledBy = k ? k.name : ''; o.handledKey = k ? k.key : ''; }
    return o;
  };
  const send = (ws, payload) => { if (ws.readyState === 1) ws.send(JSON.stringify(payload)); };
  const toAdmins = (payload, except) => { for (const a of admins) if (a !== except) send(a, payload); };
  // the same event for every admin; `notify` tells that admin's screen to ring / pop up a card (only the `targets` get true)
  const toAdminsWith = (payload, targets, except) => { for (const a of admins) if (a !== except) send(a, { ...payload, notify: !!(targets && targets.has(a)) }); };
  // does this conversation need a person right now? (AI off, a person already took over, or the AI asked for one)
  const humanNeeded = c => !support.enabled() || !!c.aiPaused || !!c.needsHuman;
  // who gets told: the admin already handling this student (if online), otherwise every admin who is not in a chat or on a call
  function alertTargets(conv) {
    const out = new Set();
    const claim = agents.claimOf(conv.key);
    if (claim) for (const a of admins) if (a.agentKey === claim.key) out.add(a);
    if (out.size) return out;
    for (const a of admins) if (!agents.isBusy(a.agentKey)) out.add(a);
    return out;
  }
  const toVisitor = (key, payload, except) => { for (const v of visitors.get(key) || []) if (v !== except) send(v, payload); };
  const toAllVisitors = payload => { for (const set of visitors.values()) for (const v of set) send(v, payload); };

  // Per-socket FIFO so two quick messages are stored in the order they were sent.
  function queue(ws, fn) {
    ws.q = (ws.q || Promise.resolve()).then(fn).catch(err => {
      console.error('Chat error:', err && err.message ? err.message : err);
      send(ws, { t: 'error', text: 'Something went wrong. Please try again.' });
    });
  }

  function allowSend(ws) {
    const now = Date.now();
    ws.sendTimes = (ws.sendTimes || []).filter(t => now - t < SEND_WINDOW_MS);
    if (ws.sendTimes.length >= SEND_BURST) return false;
    const rec = ipSends.get(ws.ip);
    if (!rec || now - rec.start > 60000) ipSends.set(ws.ip, { n: 1, start: now });
    else if (++rec.n > IP_SEND_PER_MIN) return false;
    ws.sendTimes.push(now);
    return true;
  }

  // ---------------- visitors ----------------
  function unbind(ws) {
    if (!ws.key) return;
    const set = visitors.get(ws.key);
    if (set) { set.delete(ws); if (!set.size) visitors.delete(ws.key); }
    if (ws.convId && !isOnline(ws.key)) {
      toAdmins({ t: 'presence', cid: ws.convId, online: false });
      toAdmins({ t: 'typing', cid: ws.convId, on: false });
    }
    ws.key = null; ws.convId = null;
  }

  async function sendReady(ws) {
    const conv = await store.getByKey(ws.key);
    ws.convId = conv ? conv.id : null;
    const messages = conv ? await store.getMessages(conv.id, 100) : [];
    send(ws, {
      t: 'ready', adminOnline: adminOnline(), ai: support.enabled(), aiName: support.AI_NAME(), status: conv ? conv.status : 'open',
      messages: messages.map(publicMsg), name: ws.name || (conv && conv.name) || '',
      agent: (agents.claimOf(ws.key) || {}).name || ''
    });
    if (conv) toAdmins({ t: 'presence', cid: conv.id, online: true });
  }

  async function onHello(ws, msg) {
    let key, userId = null, name = cleanName(msg.name), email = cleanEmail(msg.email);
    const user = msg.token ? verifyJwt(msg.token) : null;
    if (user && user.id) {
      key = 'u' + Number(user.id); userId = Number(user.id);
      name = cleanName(user.name) || name; email = cleanEmail(user.email) || email;
    } else if (GUEST_ID_RX.test(String(msg.visitorId || ''))) {
      key = 'g_' + msg.visitorId;
    } else {
      return send(ws, { t: 'error', text: 'Invalid chat identity.' });
    }
    if (ws.key !== key) { unbind(ws); ws.key = key; if (!visitors.has(key)) visitors.set(key, new Set()); visitors.get(key).add(ws); }
    ws.userId = userId; ws.name = name; ws.email = email;

    // Keep the stored name / email fresh (e.g. a guest filled in the form, a student changed their name).
    const existing = await store.getByKey(key);
    if (existing && ((name && name !== existing.name) || (email && email !== existing.email))) {
      const upd = await store.updateVisitor(existing.id, { name: name || undefined, email: email || undefined, userId: userId || undefined });
      toAdmins({ t: 'conv', conv: publicConv(upd, true) });
    }
    await sendReady(ws);
  }

  async function onVisitorSend(ws, msg) {
    if (!ws.key) return send(ws, { t: 'error', text: 'Not connected.' });
    const tmp = String(msg.tmp || '').slice(0, 40);
    const text = cleanText(msg.text);
    if (!text) return;

    // A message re-sent after a reconnect must not be stored twice.
    const dupKey = ws.key + ':' + tmp;
    if (tmp && recentTmp.has(dupKey)) return send(ws, { t: 'ack', tmp, message: publicMsg(recentTmp.get(dupKey).message) });
    if (!allowSend(ws)) return send(ws, { t: 'error', tmp, text: 'You are sending messages too fast. Please slow down.', code: 'RATE' });

    let conv = await store.getByKey(ws.key);
    if (!conv) conv = await store.create({ key: ws.key, userId: ws.userId, name: ws.name || 'Guest', email: ws.email });
    ws.convId = conv.id;
    if (conv.status === 'closed') { await store.setStatus(conv.id, 'open'); toVisitor(ws.key, { t: 'status', status: 'open' }); }

    const m = await store.addMessage({ cid: conv.id, sender: 'visitor', text });
    if (tmp) {
      recentTmp.set(dupKey, { message: m, at: Date.now() });
      if (recentTmp.size > 2000) for (const k of recentTmp.keys()) { recentTmp.delete(k); if (recentTmp.size <= 1500) break; }
    }
    const fresh = await store.getById(conv.id);
    send(ws, { t: 'ack', tmp, message: publicMsg(m) });
    toVisitor(ws.key, { t: 'msg', message: publicMsg(m) }, ws);          // the visitor's other tabs
    agents.touch(conv.key);
    toAdminsWith({ t: 'msg', cid: conv.id, message: publicMsg(m), conv: publicConv(fresh, true) }, humanNeeded(fresh) ? alertTargets(fresh) : null);
    toAdmins({ t: 'typing', cid: conv.id, on: false });
    scheduleAi(conv.id, ws);
  }

  // ---------------- AI support assistant ----------------
  // The assistant answers every visitor message unless a human took over (an admin replied) or it handed the chat
  // over itself (escalate_to_human). It runs in the background so the visitor's socket queue is never blocked.
  const aiSlot = () => new Promise(resolve => { if (aiActive < AI_PARALLEL) { aiActive++; resolve(); } else aiQueue.push(resolve); });
  const aiRelease = () => { const next = aiQueue.shift(); if (next) next(); else aiActive--; };

  function scheduleAi(cid, ws) {
    if (!support.enabled()) return;
    const st = aiState.get(cid) || {};
    st.userId = ws.userId || null; st.key = ws.key;
    aiState.set(cid, st);
    if (st.running) { st.again = true; return; }
    st.running = true;
    (async () => {
      try { do { st.again = false; await runAi(cid, st); } while (st.again); }
      catch (err) { console.error('AI support error:', err && err.message ? err.message : err); }
      finally { aiState.delete(cid); }
    })();
  }

  async function postAi(conv, text) {
    const m = await store.addMessage({ cid: conv.id, sender: 'admin', adminName: support.AI_NAME(), text });
    const fresh = await store.getById(conv.id);
    toVisitor(conv.key, { t: 'msg', message: publicMsg(m) });
    toVisitor(conv.key, { t: 'typing', on: false });
    toAdmins({ t: 'msg', cid: conv.id, message: publicMsg(m), conv: publicConv(fresh, isOnline(conv.key)) });
    return m;
  }

  async function runAi(cid, st) {
    let conv = await store.getById(cid);
    if (!conv || conv.aiPaused) return;
    const now = Date.now();
    const runs = (aiRuns.get(st.key) || []).filter(t => now - t < 600000);
    if (runs.length >= AI_RUNS_PER_10MIN) { aiRuns.set(st.key, runs); return; }
    runs.push(now); aiRuns.set(st.key, runs);

    const messages = await store.getMessages(cid, 30);
    const history = toAiHistory(messages);
    if (!history.length || history[history.length - 1].role !== 'user') return;

    const writes = (aiWrites.get(cid) || []).filter(t => now - t < 3600000);
    await aiSlot();
    const typing = setInterval(() => toVisitor(conv.key, { t: 'typing', on: true }), 4000);
    toVisitor(conv.key, { t: 'typing', on: true });
    let out = null, failure = null;
    try {
      out = await withTimeout(support.respond({ userId: st.userId, history, writesLeft: AI_WRITES_PER_HOUR - writes.length }), AI_TIMEOUT_MS);
    } catch (err) { failure = err; }
    finally { clearInterval(typing); aiRelease(); }

    conv = await store.getById(cid);
    if (!conv) return;                                         // deleted while the AI was thinking
    toVisitor(conv.key, { t: 'typing', on: false });

    if (failure) {
      console.error('AI support reply failed:', failure.message);
      const last = aiLastFallback.get(cid) || 0;
      if (Date.now() - last > 600000 && !conv.aiPaused) {
        aiLastFallback.set(cid, Date.now());
        await postAi(conv, AI_FALLBACK);
      }
      const upd = await store.setAi(cid, { needsHuman: true, note: 'AI could not answer: ' + String(failure.message).slice(0, 200) });
      toAdminsWith({ t: 'handoff', cid, conv: publicConv(upd, isOnline(conv.key)) }, alertTargets(upd));
      return;
    }

    // whatever the AI already changed is logged even if a human took over meanwhile
    for (const a of out.actions) {
      if (a.write && a.ok && a.tool !== 'escalate_to_human') writes.push(Date.now());
      const rec = await store.addAction({ cid, userId: st.userId, tool: a.tool, ok: a.ok, summary: a.summary });
      if (rec) toAdmins({ t: 'action', cid, action: publicAction(rec) });
    }
    aiWrites.set(cid, writes);
    if (conv.aiPaused) return;                                 // a human answered in the meantime: drop the AI's text

    const text = out.text || (out.handoff ? 'আমি বিষয়টি সাপোর্ট টিমকে জানিয়েছি, তারা শিগগিরই এখানে উত্তর দেবে।' : '');
    if (text) await postAi(conv, text);

    if (out.handoff) {
      const upd = await store.setAi(cid, { paused: true, needsHuman: true, note: `[${out.handoff.category}${out.handoff.urgency === 'high' ? ' · HIGH' : ''}] ${out.handoff.summary}` });
      toAdminsWith({ t: 'handoff', cid, conv: publicConv(upd, isOnline(conv.key)) }, alertTargets(upd));
    } else if (text) {
      // the AI dealt with it: its reply counts as read, so the admin inbox only lights up for chats that need a human
      const r = await store.markRead(cid, 'admin');
      if (r.changed) toVisitor(conv.key, { t: 'read', by: 'admin', ts: r.ts });
      const upd = await store.getById(cid);
      toAdmins({ t: 'conv', conv: publicConv(upd, isOnline(conv.key)) });
    }
  }

  async function handleVisitor(ws, msg) {
    switch (msg.t) {
      case 'hello': return onHello(ws, msg);
      case 'send': return onVisitorSend(ws, msg);
      case 'typing':
        if (ws.convId) toAdmins({ t: 'typing', cid: ws.convId, on: !!msg.on });
        return;
      case 'read': {
        if (!ws.convId) return;
        const r = await store.markRead(ws.convId, 'visitor');
        if (r.changed) toAdmins({ t: 'read', cid: ws.convId, by: 'visitor', ts: r.ts });
        return;
      }
      default: return;
    }
  }

  // ---------------- admins ----------------
  async function sendInit(ws) {
    const list = await store.list(300);
    send(ws, { t: 'init', name: ADMIN_NAME(), me: ws.agentName, meKey: ws.agentKey, busy: agents.isBusy(ws.agentKey), ai: support.enabled(), aiName: support.AI_NAME(), conversations: list.map(c => publicConv(c, isOnline(c.key))) });
  }

  async function handleAdmin(ws, msg) {
    const cid = Number(msg.cid);
    switch (msg.t) {
      case 'open': {
        const conv = await store.getById(cid);
        if (!conv) return send(ws, { t: 'gone', cid });
        const messages = await store.getMessages(cid, 300);
        const r = await store.markRead(cid, 'admin');
        const actions = await store.getActions(cid, 100);
        send(ws, { t: 'history', cid, actions: actions.map(publicAction), messages: messages.map(m => publicMsg(m.sender === 'visitor' && !m.readTs ? { ...m, readTs: r.ts } : m)),
          conv: publicConv({ ...conv, unread: 0 }, isOnline(conv.key)) });
        if (r.changed) {
          toVisitor(conv.key, { t: 'read', by: 'admin', ts: r.ts });
          toAdmins({ t: 'conv', conv: publicConv({ ...conv, unread: 0 }, isOnline(conv.key)) }, ws);
        }
        return;
      }
      case 'send': {
        const text = cleanText(msg.text);
        const conv = await store.getById(cid);
        if (!conv) return send(ws, { t: 'gone', cid });
        if (!text) return;
        if (!allowSend(ws)) return send(ws, { t: 'error', tmp: msg.tmp, text: 'Sending too fast.', code: 'RATE' });
        const held = agents.claimOf(conv.key);
        if (held && held.key !== ws.agentKey && holderOnline(held)) {
          return send(ws, { t: 'error', tmp: String(msg.tmp || ''), cid, code: 'ASSIGNED', by: held.name, text: held.name + ' is handling this chat. Press "Take over" first.' });
        }
        const m = await store.addMessage({ cid, sender: 'admin', adminName: ws.agentName || ADMIN_NAME(), text });
        if (!held || held.key !== ws.agentKey) agents.claim(conv.key, { key: ws.agentKey, name: ws.agentName }, cid);   // answering = accepting the chat
        else agents.touch(conv.key);
        // a human answering takes the conversation over: the AI stays quiet until an admin presses "Resume AI"
        if (support.enabled()) await store.setAi(cid, { paused: true, needsHuman: false });
        const fresh = await store.getById(cid);
        const pc = publicConv(fresh, isOnline(conv.key));
        send(ws, { t: 'ack', tmp: String(msg.tmp || ''), cid, message: publicMsg(m), conv: pc });
        toAdmins({ t: 'msg', cid, message: publicMsg(m), conv: pc }, ws);
        toVisitor(conv.key, { t: 'msg', message: publicMsg(m) });
        toVisitor(conv.key, { t: 'typing', on: false });
        return;
      }
      case 'typing': {
        const conv = await store.getById(cid);
        if (conv) toVisitor(conv.key, { t: 'typing', on: !!msg.on });
        return;
      }
      case 'read': {
        const conv = await store.getById(cid);
        if (!conv) return;
        const r = await store.markRead(cid, 'admin');
        if (r.changed) {
          toVisitor(conv.key, { t: 'read', by: 'admin', ts: r.ts });
          toAdmins({ t: 'conv', conv: publicConv({ ...conv, unread: 0 }, isOnline(conv.key)) });
        }
        return;
      }
      case 'status': {
        const status = msg.status === 'closed' ? 'closed' : 'open';
        const conv = await store.setStatus(cid, status);
        if (!conv) return send(ws, { t: 'gone', cid });
        if (status === 'closed') agents.release(conv.key, 'resolved');       // resolved: this admin is free again
        toAdmins({ t: 'conv', conv: publicConv(conv, isOnline(conv.key)) });
        toVisitor(conv.key, { t: 'status', status });
        return;
      }
      case 'claim': {                 // { t: 'claim', cid, force? } - accept this student's chat (force = take it over from another admin)
        const conv = await store.getById(cid);
        if (!conv) return send(ws, { t: 'gone', cid });
        const held = agents.claimOf(conv.key);
        if (held && held.key !== ws.agentKey && holderOnline(held) && !msg.force) return send(ws, { t: 'claim-denied', cid, by: held.name });
        if (!held || held.key !== ws.agentKey) agents.claim(conv.key, { key: ws.agentKey, name: ws.agentName }, cid);
        else agents.touch(conv.key);
        return send(ws, { t: 'claimed', cid });
      }
      case 'release': {               // { t: 'release', cid } - I am done with this chat; other admins can be notified again
        const conv = await store.getById(cid);
        const held = conv && agents.claimOf(conv.key);
        if (held && held.key === ws.agentKey) agents.release(conv.key, 'released');
        return;
      }
      case 'ai': {
        // { t: 'ai', cid, on: true|false } - resume or pause the AI assistant for this conversation
        const conv = await store.setAi(cid, msg.on ? { paused: false, needsHuman: false, note: '' } : { paused: true });
        if (!conv) return send(ws, { t: 'gone', cid });
        toAdmins({ t: 'conv', conv: publicConv(conv, isOnline(conv.key)) });
        return;
      }
      case 'delete': {
        const conv = await store.getById(cid);
        if (!conv) return send(ws, { t: 'gone', cid });
        agents.release(conv.key, 'deleted');
        await store.remove(cid);
        toAdmins({ t: 'deleted', cid });
        toVisitor(conv.key, { t: 'reset' });
        for (const v of visitors.get(conv.key) || []) v.convId = null;
        return;
      }
      default: return;
    }
  }

  // ---------------- who is handling whom (also changed by the calling hub when an admin accepts a call) ----------------
  const graceTimers = new Map();                      // agent key -> timer
  const sameKey = key => [...admins].filter(a => a.agentKey === key);
  const onAssigned = async ({ visitorKey, key, name, previous }) => {
    try {
      toVisitor(visitorKey, { t: 'agent', name });
      const conv = await store.getByKey(visitorKey);
      if (!conv) return;
      toAdmins({ t: 'conv', conv: publicConv(conv, isOnline(visitorKey)) });
      for (const a of admins) if (a.agentKey !== key) send(a, { t: 'alert-gone', cid: conv.id, by: name });     // their pop-up is no longer needed
      if (previous && previous.key !== key) for (const a of sameKey(previous.key)) send(a, { t: 'taken-over', cid: conv.id, by: name });
    } catch (e) { console.error('Chat assign error:', e && e.message ? e.message : e); }
  };
  const onReleased = async ({ visitorKey, why }) => {
    try {
      toVisitor(visitorKey, { t: 'agent', name: '', why });
      const conv = await store.getByKey(visitorKey);
      if (conv) toAdmins({ t: 'conv', conv: publicConv(conv, isOnline(visitorKey)) });
    } catch (e) { console.error('Chat release error:', e && e.message ? e.message : e); }
  };
  const onBusy = ({ key, busy }) => { for (const a of sameKey(key)) send(a, { t: 'me', busy }); };
  // an admin just became free: tell them about a student who is still waiting for a person
  const onFree = async ({ key }) => {
    try {
      const mine = sameKey(key); if (!mine.length) return;
      const fresh = Date.now() - WAITING_MAX_AGE_MS;                  // old unanswered chats are not worth a pop-up
      const waiting = (await store.list(300)).filter(c => c.status !== 'closed' && c.lastMs >= fresh && !agents.claimOf(c.key) && humanNeeded(c) && (c.needsHuman || c.lastSender === 'visitor'))
        .sort((x, y) => x.lastMs - y.lastMs);
      if (!waiting.length) return;
      const c = waiting[0];
      for (const a of mine) send(a, { t: 'waiting', count: waiting.length, cid: c.id, conv: publicConv(c, isOnline(c.key)), notify: true });
    } catch (e) { console.error('Chat waiting error:', e && e.message ? e.message : e); }
  };
  agents.on('assigned', onAssigned); agents.on('released', onReleased); agents.on('busy', onBusy); agents.on('free', onFree);

  // ---------------- connections ----------------
  wss.on('connection', (ws, req, role, info) => {
    ws.role = role; ws.ip = clientIp(req); ws.isAlive = true;
    ipSockets.set(ws.ip, (ipSockets.get(ws.ip) || 0) + 1);
    ws.on('pong', () => { ws.isAlive = true; });
    ws.on('error', () => {});
    ws.on('message', (raw, isBinary) => {
      if (isBinary) return;
      let msg;
      try { msg = JSON.parse(raw.toString()); } catch (e) { return; }
      if (!msg || typeof msg.t !== 'string') return;
      queue(ws, () => (role === 'admin' ? handleAdmin(ws, msg) : handleVisitor(ws, msg)));
    });
    ws.on('close', () => {
      const n = (ipSockets.get(ws.ip) || 1) - 1;
      if (n <= 0) ipSockets.delete(ws.ip); else ipSockets.set(ws.ip, n);
      if (role === 'admin') {
        admins.delete(ws);
        if (!admins.size) toAllVisitors({ t: 'presence', adminOnline: false });
        const key = ws.agentKey;                      // the last tab of this admin closed: after a short grace (page reload) their chats go back to the team
        if (key && !sameKey(key).length) {
          const t = setTimeout(() => { graceTimers.delete(key); if (!sameKey(key).length) agents.releaseAllOf(key, 'offline'); }, ADMIN_GRACE_MS());
          t.unref(); graceTimers.set(key, t);
        }
      } else unbind(ws);
    });

    if (role === 'admin') {
      const who = info || agents.identify(null);
      ws.agentKey = who.key; ws.agentName = who.name;
      clearTimeout(graceTimers.get(ws.agentKey)); graceTimers.delete(ws.agentKey);
      const first = !admins.size;
      admins.add(ws);
      if (first) toAllVisitors({ t: 'presence', adminOnline: true });
      queue(ws, () => sendInit(ws));
    }
  });

  server.on('upgrade', (req, socket, head) => {
    let pathname;
    try { pathname = new URL(req.url, 'http://internal').pathname; } catch (e) { return socket.destroy(); }
    const reject = (code, text) => { try { socket.write(`HTTP/1.1 ${code} ${text}\r\nConnection: close\r\nContent-Length: 0\r\n\r\n`); } catch (e) { /* ignore */ } socket.destroy(); };

    if (pathname === '/call-ws' || pathname === '/admin/call-ws') return;     // handled by backend/calling/hub.js
    if (pathname !== '/chat-ws' && pathname !== '/admin/chat-ws') return socket.destroy();
    if (!sameOrigin(req, { allowApp: pathname === '/chat-ws' })) return reject(403, 'Forbidden');
    const role = pathname === '/admin/chat-ws' ? 'admin' : 'visitor';
    const open = info => {
      if ((ipSockets.get(clientIp(req)) || 0) >= MAX_SOCKETS_PER_IP) return reject(429, 'Too Many Requests');
      wss.handleUpgrade(req, socket, head, ws => wss.emit('connection', ws, req, role, info));
    };
    if (role !== 'admin') return open();
    // support team: the main admin, or a sub-admin the main admin gave the "Live chat" module (checked in the database)
    require('../admin/admin-auth').resolve(req).then(a => {
      if (!a || a.restricted || !a.can({ mods: ['chat'], level: 'view' })) return reject(401, 'Unauthorized');
      open(agents.identify(a));
    }).catch(() => reject(500, 'Server Error'));
  });

  const heartbeat = setInterval(() => {
    for (const ws of wss.clients) {
      if (!ws.isAlive) { ws.terminate(); continue; }
      ws.isAlive = false;
      try { ws.ping(); } catch (e) { /* closing */ }
    }
    const cutoff = Date.now() - 10 * 60 * 1000;
    for (const [k, v] of recentTmp) if (v.at < cutoff) recentTmp.delete(k);
  }, HEARTBEAT_MS);
  heartbeat.unref();
  server.on('close', () => clearInterval(heartbeat));

  return {
    // Switch to MySQL once the app's database is connected. Falls back to memory if the tables can't be created.
    async useDatabase(db) {
      try {
        const next = createMysqlStore(db);
        await next.init();
        store = next;
        console.log('Live chat: using MySQL storage.');
        for (const set of visitors.values()) for (const ws of set) queue(ws, () => sendReady(ws));
        for (const a of admins) queue(a, () => sendInit(a));
      } catch (err) {
        console.error('Live chat: could not prepare MySQL tables, keeping messages in memory only:', err.message);
      }
    },
    // test helper
    _store: () => store,
    _wss: wss,
    _idle: () => new Promise(resolve => { const t = setInterval(() => { if (!aiState.size) { clearInterval(t); resolve(); } }, 10); }),
    close() {
      clearInterval(heartbeat);
      agents.off('assigned', onAssigned); agents.off('released', onReleased); agents.off('busy', onBusy); agents.off('free', onFree);
      for (const t of graceTimers.values()) clearTimeout(t);
      for (const ws of wss.clients) ws.terminate();
      wss.close();
    }
  };
}

module.exports = { attach, verifyJwt, sameOrigin, clientIp };   // the helpers are shared with backend/calling/hub.js
