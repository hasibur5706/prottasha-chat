package com.example.pulsechat

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.Manifest
import android.view.SurfaceView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import io.agora.rtc2.ChannelMediaOptions
import io.agora.rtc2.Constants
import io.agora.rtc2.IRtcEngineEventHandler
import io.agora.rtc2.RtcEngine
import io.agora.rtc2.RtcEngineConfig
import io.agora.rtc2.video.VideoCanvas
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject

val Violet = Color(0xFF7C4DFF); val Cyan = Color(0xFF00E5FF); val Pink = Color(0xFFFF4081)
val Ink = Color(0xFF0E0B1F); val CardBg = Color(0xFF1A1536)

data class Contact(val id: Int, val name: String, val phone: String, val color: Color = palette[id % palette.size], val last: String = "", val unread: Int = 0, val online: Boolean = false)
data class CallReq(val c: Contact, val video: Boolean, val callId: Int = 0, val channel: String = "", val incoming: Boolean = false)
data class Msg(val text: String, val mine: Boolean, val id: Long = 0)

val palette = listOf(Violet, Cyan, Pink, Color(0xFFFFAB40), Color(0xFF69F0AE))

class MainActivity : ComponentActivity() {
    override fun onStart() { super.onStart(); AppState.fg = true }
    override fun onStop() { super.onStop(); AppState.fg = false }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("pulse", Context.MODE_PRIVATE)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Violet, background = Ink, surface = CardBg, onSurface = Color.White)) {
                Surface(Modifier.fillMaxSize(), color = Ink) { App(prefs) }
            }
        }
    }
}

@Composable fun App(p: SharedPreferences) {
    var name by remember { mutableStateOf(p.getString("name", "") ?: "") }
    var phone by remember { mutableStateOf(p.getString("phone", "") ?: "") }
    var token by remember { mutableStateOf(p.getString("token", "") ?: "") }
    Crossfade(token.isNotBlank(), label = "root") { registered ->
        if (registered) Home(name, phone, token) { p.edit().clear().apply(); name = ""; phone = ""; token = "" }
        else Register { n, ph, t -> p.edit().putString("name", n).putString("phone", ph).putString("token", t).apply(); name = n; phone = ph; token = t }
    }
}

@Composable fun animBrush(): Brush {
    val t = rememberInfiniteTransition(label = "bg")
    val o by t.animateFloat(0f, 1000f, infiniteRepeatable(tween(8000, easing = LinearEasing), RepeatMode.Reverse), label = "o")
    return Brush.linearGradient(listOf(Color(0xFF1B0F4D), Color(0xFF4A148C), Ink), Offset(o, 0f), Offset(1000f - o, 2000f))
}

@Composable fun Avatar(c: Contact, size: Dp = 48.dp) =
    Box(Modifier.size(size).background(Brush.linearGradient(listOf(c.color, c.color.copy(alpha = .55f))), CircleShape), Alignment.Center) {
        Text(c.name.first().toString(), fontSize = (size.value / 2.4f).sp, fontWeight = FontWeight.Bold, color = Color.White)
    }

// ---------- Registration ----------
@Composable fun Register(onDone: (String, String, String) -> Unit) {
    var n by remember { mutableStateOf("") }; var ph by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }; var err by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { show = true }
    val ok = n.trim().length >= 2 && ph.length in 8..15
    val inf = rememberInfiniteTransition(label = "logo")
    val pulse by inf.animateFloat(1f, 1.12f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p")
    Box(Modifier.fillMaxSize().background(animBrush()).padding(28.dp), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.prottasha_logo), "Prottasha logo", Modifier.size(112.dp).scale(pulse))
            Spacer(Modifier.height(20.dp))
            Text("Prottasha", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text("Chat. Call. Connect.", color = Color.White.copy(alpha = .7f))
            Spacer(Modifier.height(32.dp))
            AnimatedVisibility(show, enter = fadeIn(tween(700)) + slideInVertically(tween(700)) { it / 3 }) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    OutlinedTextField(n, { n = it.take(30) }, Modifier.fillMaxWidth(), label = { Text("Your name") },
                        leadingIcon = { Icon(Icons.Filled.Person, null) }, singleLine = true, shape = RoundedCornerShape(16.dp))
                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(ph, { v -> ph = v.filter(Char::isDigit).take(15) }, Modifier.fillMaxWidth(),
                        label = { Text("Phone number (with country code)") }, leadingIcon = { Icon(Icons.Filled.Call, null) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true, shape = RoundedCornerShape(16.dp))
                    Spacer(Modifier.height(24.dp))
                    err?.let { Text(it, color = Pink, modifier = Modifier.padding(bottom = 8.dp)) }
                    Button({
                        scope.launch {
                            busy = true; err = null
                            try {
                                val r = Api.call("register", null, JSONObject().put("name", n.trim()).put("phone", ph))
                                if (r.optBoolean("ok")) onDone(n.trim(), ph, r.getString("token")) else err = r.optString("error", "Something went wrong")
                            } catch (e: Exception) { err = "Can't reach the server" }
                            busy = false
                        }
                    }, Modifier.fillMaxWidth().height(54.dp), enabled = ok && !busy, shape = RoundedCornerShape(16.dp)) {
                        Text(if (busy) "Please wait…" else "Get Started", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ---------- Home ----------
@Composable fun Home(me: String, phone: String, token: String, logout: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var chat by remember { mutableStateOf<Contact?>(null) }
    var call by remember { mutableStateOf<CallReq?>(null) }
    var people by remember { mutableStateOf<List<Contact>>(emptyList()) }
    LaunchedEffect(Unit) {
        while (true) {
            try {
                if (!AppState.fg) { delay(2000); continue }
                val a = Api.call("users", token).optJSONArray("users")
                if (a != null) people = List(a.length()) { val o = a.getJSONObject(it); Contact(o.getInt("id"), o.getString("name"), o.getString("phone"), online = o.optBoolean("online")) }
            } catch (e: Exception) { }
            delay(8000)
        }
    }
    val scope = rememberCoroutineScope()
    var incoming by remember { mutableStateOf<CallReq?>(null) }
    LaunchedEffect(Unit) {   // listen for incoming calls (also keeps you "online")
        while (true) {
            if (AppState.fg) try {
                val i = Api.call("call_poll", token).optJSONObject("incoming")
                if (i != null && call == null && incoming?.callId != i.getInt("id")) {
                    incoming = CallReq(Contact(i.getInt("from_id"), i.getString("name"), i.getString("phone")), i.getInt("video") == 1, i.getInt("id"), i.getString("channel"), true)
                } else if (i == null && incoming != null) incoming = null
            } catch (e: Exception) { }
            delay(2000)
        }
    }
    var showAdd by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }
    LaunchedEffect(refresh) {
        if (refresh > 0) try {
            val a = Api.call("users", token).optJSONArray("users")
            if (a != null) people = List(a.length()) { val o = a.getJSONObject(it); Contact(o.getInt("id"), o.getString("name"), o.getString("phone"), online = o.optBoolean("online")) }
        } catch (e: Exception) { }
    }
    Box(Modifier.fillMaxSize()) {
        Scaffold(containerColor = Ink, floatingActionButton = {
            if (tab == 0) FloatingActionButton({ showAdd = true }, containerColor = Violet, shape = CircleShape) { Icon(Icons.Filled.PersonAdd, "Add contact", tint = Color.White) }
        }, bottomBar = {
            NavigationBar(containerColor = CardBg) {
                listOf("Chats" to Icons.Filled.Chat, "Calls" to Icons.Filled.Call, "Me" to Icons.Filled.Person).forEachIndexed { i, (l, ic) ->
                    NavigationBarItem(tab == i, { tab = i }, { Icon(ic, l) }, label = { Text(l) })
                }
            }
        }) { pad ->
            AnimatedContent(tab, Modifier.padding(pad), transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) }, label = "tab") { t ->
                when (t) { 0 -> ChatList(me, people) { chat = it }; 1 -> CallList(people) { c, v -> call = CallReq(c, v) }; else -> Profile(me, phone, logout) }
            }
        }
        if (showAdd) AddContactDialog(token, { showAdd = false }) { refresh++ }
        AnimatedVisibility(chat != null, enter = slideInHorizontally { it } + fadeIn(), exit = slideOutHorizontally { it } + fadeOut()) {
            chat?.let { c -> ChatScreen(c, token, { chat = null }) { v -> call = CallReq(c, v) } }
        }
        incoming?.let { inc ->
            if (call == null) IncomingCall(inc,
                onAccept = { scope.launch {
                    val ok = try { Api.call("call_answer", token, JSONObject().put("id", inc.callId).put("action", "accept")).optBoolean("ok") } catch (e: Exception) { false }
                    incoming = null; if (ok) call = inc
                } },
                onDecline = { scope.launch {
                    try { Api.call("call_answer", token, JSONObject().put("id", inc.callId).put("action", "decline")) } catch (e: Exception) { }
                    incoming = null
                } })
        }
        AnimatedVisibility(call != null, enter = fadeIn() + scaleIn(initialScale = .9f), exit = fadeOut()) {
            call?.let { CallScreen(it, token) { call = null } }
        }
    }
}

@Composable fun ChatList(me: String, people: List<Contact>, open: (Contact) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Hi, $me 👋", fontSize = 26.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(6.dp)) }
        if (people.isEmpty()) item { Text("No contacts yet. Tap the + button to add someone by phone number.", color = Color.White.copy(alpha = .6f)) }
        items(people) { c ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CardBg).clickable { open(c) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box { Avatar(c, 52.dp); if (c.online) Box(Modifier.align(Alignment.BottomEnd).size(14.dp).background(Color(0xFF25D366), CircleShape).border(2.dp, CardBg, CircleShape)) }; Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(c.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text("+${c.phone}", color = Color.White.copy(alpha = .6f), maxLines = 1, fontSize = 13.sp)
                }
                if (c.unread > 0) Box(Modifier.size(24.dp).background(Pink, CircleShape), Alignment.Center) { Text("${c.unread}", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable fun CallList(people: List<Contact>, call: (Contact, Boolean) -> Unit) {
    val kinds = listOf("Incoming · 2m", "Outgoing · 14m", "Missed", "Outgoing · 1m", "Incoming · 8m")
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Calls", fontSize = 26.sp, fontWeight = FontWeight.Bold) }
        items(people.size) { i ->
            val c = people[i]
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CardBg).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Avatar(c); Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(c.name, fontWeight = FontWeight.SemiBold)
                    Text("+${c.phone}", color = Color.White.copy(alpha = .6f), fontSize = 13.sp)
                }
                IconButton({ call(c, true) }) { Icon(Icons.Filled.Videocam, "Video call", tint = Cyan) }
                IconButton({ call(c, false) }) { Icon(Icons.Filled.Call, "Call", tint = Cyan) }
            }
        }
    }
}

@Composable fun Profile(me: String, phone: String, logout: () -> Unit) {
    var notif by remember { mutableStateOf(true) }; var receipts by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Avatar(Contact(0, me, phone, Violet), 110.dp)
        Spacer(Modifier.height(14.dp))
        Text(me, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("+$phone", color = Color.White.copy(alpha = .6f))
        Spacer(Modifier.height(28.dp))
        listOf("Notifications" to (notif to { v: Boolean -> notif = v }), "Read receipts" to (receipts to { v: Boolean -> receipts = v })).forEach { (l, s) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(l, Modifier.weight(1f)); Switch(s.first, s.second)
            }
        }
        Spacer(Modifier.weight(1f))
        OutlinedButton(logout, Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp)) { Text("Log out") }
    }
}

// ---------- Chat ----------
@Composable fun ChatScreen(c: Contact, token: String, back: () -> Unit, call: (Boolean) -> Unit) {
    BackHandler(onBack = back)
    val msgs = remember { mutableStateListOf<Msg>() }
    var text by remember { mutableStateOf("") }; var typing by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    var online by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope(); val ls = rememberLazyListState()
    // Poll the server for new messages (every 2s, and right after sending)
    LaunchedEffect(c.id, tick) {
        while (true) {
            try {
                if (!AppState.fg) { delay(1000); continue }
                val last = msgs.lastOrNull()?.id ?: 0L
                val resp = Api.call("messages", token, query = "&with=${c.id}&after=$last")
                online = resp.optBoolean("online")
                val a = resp.optJSONArray("messages")
                if (a != null) for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    msgs.add(Msg(o.getString("body"), o.getInt("from_id") != c.id, o.getLong("id")))
                }
            } catch (e: Exception) { }
            delay(2000)
        }
    }
    LaunchedEffect(msgs.size, typing) { if (msgs.isNotEmpty()) ls.animateScrollToItem(msgs.size) }
    fun send(t: String) {
        if (t.isBlank()) return
        val body = t.trim(); text = ""
        scope.launch {
            try { Api.call("send", token, JSONObject().put("to_id", c.id).put("body", body)); tick++ } catch (e: Exception) { }
        }
    }
    Column(Modifier.fillMaxSize().background(Ink).statusBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().background(CardBg).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(back) { Icon(Icons.Filled.ArrowBack, "Back") }
            Avatar(c, 40.dp); Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(c.name, fontWeight = FontWeight.SemiBold)
                Text(if (online) "online" else "offline", color = if (online) Cyan else Color.White.copy(alpha = .6f), fontSize = 12.sp)
            }
            IconButton({ call(true) }) { Icon(Icons.Filled.Videocam, "Video call", tint = Cyan) }
            IconButton({ call(false) }) { Icon(Icons.Filled.Call, "Call", tint = Cyan) }
        }
        LazyColumn(Modifier.weight(1f), state = ls, contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs.size) { Bubble(msgs[it], c.color) }
            if (typing) item { Dots() }
        }
        Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("👍", "❤️", "😂", "🔥").forEach { e -> Text(e, fontSize = 22.sp, modifier = Modifier.clickable { send(e) }.padding(4.dp)) }
        }
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("Message") }, shape = RoundedCornerShape(26.dp), maxLines = 3)
            Spacer(Modifier.width(8.dp))
            FloatingActionButton({ send(text) }, containerColor = Violet, shape = CircleShape) { Icon(Icons.Filled.Send, "Send", tint = Color.White) }
        }
    }
}

@Composable fun Bubble(m: Msg, tint: Color) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val s by animateFloatAsState(if (shown) 1f else .6f, spring(Spring.DampingRatioMediumBouncy), label = "b")
    Box(Modifier.fillMaxWidth(), if (m.mine) Alignment.CenterEnd else Alignment.CenterStart) {
        Text(m.text, color = Color.White, modifier = Modifier
            .graphicsLayer { scaleX = s; scaleY = s; alpha = ((s - .6f) / .4f).coerceIn(0f, 1f); transformOrigin = TransformOrigin(if (m.mine) 1f else 0f, 1f) }
            .widthIn(max = 280.dp)
            .background(if (m.mine) Brush.linearGradient(listOf(Violet, Pink)) else Brush.linearGradient(listOf(CardBg, CardBg)), RoundedCornerShape(18.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp))
    }
}

@Composable fun Dots() {
    val inf = rememberInfiniteTransition(label = "dots")
    Row(Modifier.background(CardBg, RoundedCornerShape(18.dp)).padding(horizontal = 14.dp, vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        repeat(3) { i ->
            val y by inf.animateFloat(0f, -6f, infiniteRepeatable(tween(450), RepeatMode.Reverse, StartOffset(i * 150)), label = "d$i")
            Box(Modifier.offset(y = y.dp).size(8.dp).background(Color.White.copy(alpha = .7f), CircleShape))
        }
    }
}

// ---------- Call ----------
@Composable fun IncomingCall(r: CallReq, onAccept: () -> Unit, onDecline: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "ring")
    val s by inf.animateFloat(1f, 1.15f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "s")
    Column(Modifier.fillMaxSize().background(animBrush()).statusBarsPadding().padding(32.dp), verticalArrangement = Arrangement.SpaceBetween, horizontalAlignment = Alignment.CenterHorizontally) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(48.dp))
            Text(if (r.video) "Incoming video call" else "Incoming voice call", color = Color.White.copy(alpha = .8f))
            Spacer(Modifier.height(8.dp))
            Text(r.c.name, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        }
        Box(Modifier.scale(s)) { Avatar(r.c, 140.dp) }
        Row(Modifier.fillMaxWidth().padding(bottom = 32.dp), Arrangement.SpaceEvenly) {
            RoundBtn(Icons.Filled.CallEnd, Color(0xFFFF3B5C), 72.dp, onDecline)
            RoundBtn(if (r.video) Icons.Filled.Videocam else Icons.Filled.Call, Color(0xFF1FA855), 72.dp, onAccept)
        }
    }
}

@Composable fun CallScreen(req: CallReq, token: String, end: () -> Unit) {
    val c = req.c; val video = req.video
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var callId by remember { mutableIntStateOf(req.callId) }
    var channel by remember { mutableStateOf(req.channel) }
    var status by remember { mutableStateOf(if (req.incoming) "Connecting…" else "Calling…") }
    var note by remember { mutableStateOf("") }
    var connected by remember { mutableStateOf(req.incoming) }
    var finished by remember { mutableStateOf(false) }
    var sec by remember { mutableIntStateOf(0) }
    var mute by remember { mutableStateOf(false) }; var spk by remember { mutableStateOf(video) }
    var cam by remember { mutableStateOf(video) }
    var remoteUid by remember { mutableIntStateOf(0) }
    var granted by remember { mutableStateOf<Boolean?>(null) }
    var engine by remember { mutableStateOf<RtcEngine?>(null) }

    fun hangUp() {
        if (finished) return
        finished = true
        scope.launch {
            try { if (callId != 0) Api.call("call_answer", token, JSONObject().put("id", callId).put("action", "end")) } catch (e: Exception) { }
            end()
        }
    }
    BackHandler(onBack = { hangUp() })

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res -> granted = res.values.all { it } }
    LaunchedEffect(Unit) {
        launcher.launch(if (video) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA) else arrayOf(Manifest.permission.RECORD_AUDIO))
    }

    // Signalling: start the call (caller) and watch its status (both sides)
    LaunchedEffect(granted) {
        val g = granted ?: return@LaunchedEffect
        if (!g) {
            status = "Microphone / camera permission is needed"
            if (req.incoming) try { Api.call("call_answer", token, JSONObject().put("id", callId).put("action", "end")) } catch (e: Exception) { }
            delay(1800); finished = true; end(); return@LaunchedEffect
        }
        if (!req.incoming) {
            try {
                val r = Api.call("call_start", token, JSONObject().put("to_id", c.id).put("video", video))
                if (!r.optBoolean("ok")) { status = r.optString("error", "Call failed"); delay(1800); finished = true; end(); return@LaunchedEffect }
                callId = r.getInt("call_id"); channel = r.getString("channel"); status = "Ringing…"
            } catch (e: Exception) { status = "Can't reach the server"; delay(1800); finished = true; end(); return@LaunchedEffect }
        }
        while (!finished) {
            delay(1500)
            val s = try { Api.call("call_status", token, query = "&id=$callId").optString("status") } catch (e: Exception) { "" }
            when (s) {
                "accepted" -> connected = true
                "declined" -> { status = "Call declined"; delay(1500); finished = true; end(); return@LaunchedEffect }
                "missed" -> { status = "No answer"; delay(1500); finished = true; end(); return@LaunchedEffect }
                "ended" -> { finished = true; end(); return@LaunchedEffect }
            }
        }
    }
    LaunchedEffect(connected) { if (connected) { sec = 0; while (true) { delay(1000); sec++ } } }

    // Media: create the Agora engine (camera preview starts for video calls), join the channel once answered
    LaunchedEffect(granted) {
        if (granted != true) return@LaunchedEffect
        if (Api.AGORA_APP_ID.startsWith("PASTE")) { note = "Add your Agora App ID in Api.kt to enable audio/video"; return@LaunchedEffect }
        try {
            val e = RtcEngine.create(RtcEngineConfig().apply {
                mContext = ctx.applicationContext
                mAppId = Api.AGORA_APP_ID
                mEventHandler = object : IRtcEngineEventHandler() {
                    override fun onUserJoined(uid: Int, elapsed: Int) { remoteUid = uid }
                    override fun onUserOffline(uid: Int, reason: Int) { remoteUid = 0 }
                }
            })
            if (video) { e.enableVideo(); e.startPreview() }
            e.setEnableSpeakerphone(spk)
            engine = e
        } catch (ex: Exception) { note = "Media error: ${ex.message}" }
    }
    LaunchedEffect(connected, engine) {
        val e = engine
        if (connected && e != null && channel.isNotEmpty()) {
            e.joinChannel(null, channel, 0, ChannelMediaOptions().apply {
                clientRoleType = Constants.CLIENT_ROLE_BROADCASTER
                channelProfile = Constants.CHANNEL_PROFILE_COMMUNICATION
                publishMicrophoneTrack = true
                publishCameraTrack = video
            })
        }
    }
    DisposableEffect(Unit) { onDispose { engine?.let { it.leaveChannel(); RtcEngine.destroy() } } }

    val inf = rememberInfiniteTransition(label = "rings")
    val r by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "r")
    val e = engine
    val showVideo = video && e != null && (remoteUid != 0 || cam)
    val sb = if (video) 52.dp else 60.dp
    Box(Modifier.fillMaxSize().background(animBrush())) {
        if (showVideo && e != null) {
            if (remoteUid != 0) {
                key(remoteUid) { AndroidView({ x -> SurfaceView(x).also { e.setupRemoteVideo(VideoCanvas(it, VideoCanvas.RENDER_MODE_HIDDEN, remoteUid)) } }, Modifier.fillMaxSize()) }
            } else {
                AndroidView({ x -> SurfaceView(x).also { e.setupLocalVideo(VideoCanvas(it, VideoCanvas.RENDER_MODE_HIDDEN, 0)) } }, Modifier.fillMaxSize())
            }
        }
        Column(Modifier.fillMaxSize().statusBarsPadding().padding(32.dp), verticalArrangement = Arrangement.SpaceBetween, horizontalAlignment = Alignment.CenterHorizontally) {
            val scrim = if (showVideo) Modifier.background(Color.Black.copy(alpha = .35f), RoundedCornerShape(16.dp)).padding(horizontal = 20.dp, vertical = 10.dp) else Modifier
            Column(scrim, horizontalAlignment = Alignment.CenterHorizontally) {
                Text(c.name, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text(if (connected) "%02d:%02d".format(sec / 60, sec % 60) else status, color = Color.White.copy(alpha = .85f), fontSize = 16.sp)
                if (note.isNotEmpty()) Text(note, color = Color(0xFFFFAB40), fontSize = 12.sp)
            }
            if (showVideo) Spacer(Modifier.height(1.dp)) else Box(Modifier.size(280.dp), Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    for (i in 0..2) { val p = (r + i / 3f) % 1f; drawCircle(c.color.copy(alpha = .45f * (1 - p)), size.minDimension / 2 * (.4f + .6f * p)) }
                }
                Avatar(c, 112.dp)
            }
            Row(Modifier.fillMaxWidth().padding(bottom = 24.dp), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
                RoundBtn(if (mute) Icons.Filled.MicOff else Icons.Filled.Mic, if (mute) Violet else Color.White.copy(alpha = .2f), sb) { mute = !mute; engine?.muteLocalAudioStream(mute) }
                if (video) RoundBtn(if (cam) Icons.Filled.Videocam else Icons.Filled.VideocamOff, if (cam) Violet else Color.White.copy(alpha = .2f), sb) { cam = !cam; engine?.enableLocalVideo(cam) }
                if (video) RoundBtn(Icons.Filled.FlipCameraAndroid, Color.White.copy(alpha = .2f), sb) { engine?.switchCamera() }
                RoundBtn(Icons.Filled.CallEnd, Color(0xFFFF3B5C), 72.dp) { hangUp() }
                RoundBtn(Icons.Filled.VolumeUp, if (spk) Violet else Color.White.copy(alpha = .2f), sb) { spk = !spk; engine?.setEnableSpeakerphone(spk) }
            }
        }
        // Self-view (picture-in-picture) once the other person's video is showing
        if (video && e != null && remoteUid != 0 && cam) Box(Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(16.dp).size(96.dp, 136.dp).clip(RoundedCornerShape(16.dp)).border(2.dp, Color.White, RoundedCornerShape(16.dp))) {
            AndroidView({ x -> SurfaceView(x).also { it.setZOrderMediaOverlay(true); e.setupLocalVideo(VideoCanvas(it, VideoCanvas.RENDER_MODE_HIDDEN, 0)) } }, Modifier.fillMaxSize())
        }
    }
}

@Composable fun RoundBtn(icon: androidx.compose.ui.graphics.vector.ImageVector, bg: Color, size: Dp = 60.dp, onClick: () -> Unit) {
    val bgAnim by animateColorAsState(bg, label = "btn")
    Box(Modifier.size(size).background(bgAnim, CircleShape).clickable(onClick = onClick), Alignment.Center) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(size / 2))
    }
}


@Composable fun AddContactDialog(token: String, onClose: () -> Unit, onAdded: () -> Unit) {
    var phone by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var found by remember { mutableStateOf<Contact?>(null) }
    var checked by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("No account found for this number") }
    val scope = rememberCoroutineScope()
    val f = found
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = CardBg,
        title = { Text("Add to contacts") },
        text = {
            Column {
                OutlinedTextField(phone, { phone = it.filter(Char::isDigit).take(15); found = null; checked = false },
                    Modifier.fillMaxWidth(), label = { Text("Phone number (with country code)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), shape = RoundedCornerShape(16.dp))
                Spacer(Modifier.height(16.dp))
                if (f != null) Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(f, 44.dp); Spacer(Modifier.width(12.dp))
                    Column {
                        Text(f.name, fontWeight = FontWeight.SemiBold)
                        Text("Account available", color = Color(0xFF69F0AE), fontSize = 13.sp)
                    }
                } else if (checked) Text(msg, color = Pink)
            }
        },
        confirmButton = {
            if (f != null) TextButton(onClick = {
                scope.launch {
                    busy = true
                    try {
                        val r = Api.call("addcontact", token, JSONObject().put("contact_id", f.id))
                        if (r.optBoolean("ok")) { onAdded(); onClose() } else { found = null; checked = true; msg = r.optString("error", "Could not add contact") }
                    } catch (e: Exception) { found = null; checked = true; msg = "Can't reach the server" }
                    busy = false
                }
            }, enabled = !busy) { Text("Add to contacts") }
            else TextButton(onClick = {
                scope.launch {
                    busy = true
                    try {
                        val r = Api.call("lookup", token, query = "&phone=$phone")
                        if (r.optBoolean("found")) found = Contact(r.getInt("id"), r.getString("name"), r.getString("phone"))
                        else { found = null; msg = r.optString("error", "No account found for this number") }
                    } catch (e: Exception) { found = null; msg = "Can't reach the server" }
                    checked = true; busy = false
                }
            }, enabled = phone.length >= 8 && !busy) { Text(if (busy) "Checking…" else "Check") }
        },
        dismissButton = { TextButton(onClose) { Text("Cancel") } }
    )
}
