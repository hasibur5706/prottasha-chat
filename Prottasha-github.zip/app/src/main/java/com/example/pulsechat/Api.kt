package com.example.pulsechat

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Api {
    // Your Hostinger domain. Must be https:// (Android blocks plain http by default).
    // Get this free from console.agora.io (see instructions). Used for real voice/video.
    const val AGORA_APP_ID = "PASTE_YOUR_AGORA_APP_ID"
    const val BASE = "https://prottashaacademy.com/prottasha/api.php"

    suspend fun call(route: String, token: String?, body: JSONObject? = null, query: String = ""): JSONObject =
        withContext(Dispatchers.IO) {
            val c = URL("$BASE?r=$route$query").openConnection() as HttpURLConnection
            c.connectTimeout = 10000; c.readTimeout = 10000
            c.requestMethod = if (body == null) "GET" else "POST"
            token?.let { c.setRequestProperty("X-Token", it) }
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
            }
            val stream = if (c.responseCode < 400) c.inputStream else c.errorStream
            JSONObject(stream.bufferedReader().readText())
        }
}

// True while the app is on screen; used so "online" status is only sent when the app is open
object AppState { @Volatile var fg = true }
