package com.example.pulsechat

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

object Api {
    // Your Hostinger domain. Must be https:// (Android blocks plain http by default).
    // Get this free from console.agora.io (see instructions). Used for real voice/video.
    const val AGORA_APP_ID = "PASTE_YOUR_AGORA_APP_ID"
    const val BASE = "https://prottashaacademy.com/prottasha/api.php"

    suspend fun call(route: String, token: String?, body: JSONObject? = null, query: String = ""): JSONObject =
        withContext(Dispatchers.IO) {
            val c = URL("$BASE?r=$route$query").openConnection() as HttpURLConnection
            c.connectTimeout = 10000; c.readTimeout = 10000
            c.requestMethod = if (body == null) "GET" else "POST"
            token?.let { c.setRequestProperty("X-Token", it) }
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
            }
            val stream = if (c.responseCode < 400) c.inputStream else c.errorStream
            JSONObject(stream.bufferedReader().readText())
        }

    // Upload a file (photo, document, voice note) as multipart/form-data
    suspend fun upload(token: String, name: String, input: InputStream): JSONObject = withContext(Dispatchers.IO) {
        val b = "----pc" + System.currentTimeMillis()
        val c = URL("$BASE?r=upload").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 60000
        c.setChunkedStreamingMode(0)
        c.setRequestProperty("X-Token", token)
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$b")
        c.outputStream.use { o ->
            o.write("--$b\r\nContent-Disposition: form-data; name=\"file\"; filename=\"${name.replace("\"", "")}\"\r\nContent-Type: application/octet-stream\r\n\r\n".toByteArray())
            input.use { it.copyTo(o) }
            o.write("\r\n--$b--\r\n".toByteArray())
        }
        val s = if (c.responseCode < 400) c.inputStream else c.errorStream
        JSONObject(s.bufferedReader().readText())
    }
}

// True while the app is on screen; used so "online" status is only sent when the app is open
object AppState { @Volatile var fg = true }
