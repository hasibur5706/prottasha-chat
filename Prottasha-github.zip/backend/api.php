<?php
// Upload to public_html/api/api.php, then fill in the 4 values below (from hPanel > Databases).
header('Content-Type: application/json; charset=utf-8');
$cfg = ['host' => 'localhost', 'db' => 'u000000000_pulsechat', 'user' => 'u000000000_pulse', 'pass' => 'CHANGE_ME'];
try {
    $pdo = new PDO("mysql:host={$cfg['host']};dbname={$cfg['db']};charset=utf8mb4", $cfg['user'], $cfg['pass'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]);
} catch (Throwable $e) { http_response_code(500); exit('{"error":"Database connection failed"}'); }

$in = json_decode(file_get_contents('php://input'), true) ?: [];
function out($d, $c = 200) { http_response_code($c); echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; }
function me() {
    global $pdo;
    $t = $_SERVER['HTTP_X_TOKEN'] ?? '';
    if (!preg_match('/^[a-f0-9]{64}$/', $t)) out(['error' => 'unauthorized'], 401);
    $s = $pdo->prepare('SELECT id,name,phone FROM users WHERE token_hash=?');
    $s->execute([hash('sha256', $t)]);
    $u = $s->fetch() ?: out(['error' => 'unauthorized'], 401);
    $pdo->prepare('UPDATE users SET last_seen=NOW() WHERE id=?')->execute([$u['id']]);   // presence heartbeat
    return $u;
}

switch ($_GET['r'] ?? '') {
    case 'register':
        $n = trim($in['name'] ?? ''); $p = preg_replace('/\D/', '', $in['phone'] ?? '');
        if (mb_strlen($n) < 2 || mb_strlen($n) > 30 || strlen($p) < 8 || strlen($p) > 15) out(['error' => 'Invalid name or phone number'], 422);
        $t = bin2hex(random_bytes(32));
        try { $pdo->prepare('INSERT INTO users(name,phone,token_hash) VALUES(?,?,?)')->execute([$n, $p, hash('sha256', $t)]); }
        catch (PDOException $e) { out(['error' => 'This number is already registered'], 409); }
        out(['ok' => true, 'id' => (int)$pdo->lastInsertId(), 'token' => $t]);
    case 'users':
        $u = me();
        // Contacts the user added + anyone who has messaged them
        $s = $pdo->prepare('SELECT id,name,phone,(last_seen > NOW() - INTERVAL 20 SECOND) AS online FROM users WHERE id<>? AND (id IN (SELECT contact_id FROM contacts WHERE owner_id=?) OR id IN (SELECT from_id FROM messages WHERE to_id=?)) ORDER BY name LIMIT 500');
        $s->execute([$u['id'], $u['id'], $u['id']]);
        $rows = $s->fetchAll(); foreach ($rows as &$x) $x['online'] = (bool)$x['online'];
        out(['users' => $rows]);
    case 'lookup':
        $u = me(); $p = preg_replace('/\D/', '', $_GET['phone'] ?? '');
        $s = $pdo->prepare('SELECT id,name,phone FROM users WHERE phone=?'); $s->execute([$p]); $f = $s->fetch();
        if (!$f) out(['found' => false]);
        if ((int)$f['id'] === (int)$u['id']) out(['found' => false, 'error' => 'That is your own number']);
        out(['found' => true, 'id' => (int)$f['id'], 'name' => $f['name'], 'phone' => $f['phone']]);
    case 'addcontact':
        $u = me(); $c = (int)($in['contact_id'] ?? 0);
        if (!$c || $c === (int)$u['id']) out(['error' => 'Invalid contact'], 422);
        try { $pdo->prepare('INSERT IGNORE INTO contacts(owner_id,contact_id) VALUES(?,?)')->execute([$u['id'], $c]); }
        catch (PDOException $e) { out(['error' => 'Unknown user'], 422); }
        out(['ok' => true]);
    case 'send':
        $u = me(); $to = (int)($in['to_id'] ?? 0); $b = trim($in['body'] ?? '');
        if (!$to || $b === '' || mb_strlen($b) > 2000) out(['error' => 'Invalid message'], 422);
        try { $pdo->prepare('INSERT INTO messages(from_id,to_id,body) VALUES(?,?,?)')->execute([$u['id'], $to, $b]); }
        catch (PDOException $e) { out(['error' => 'Unknown recipient'], 422); }
        out(['ok' => true, 'id' => (int)$pdo->lastInsertId()]);
    case 'messages':
        $u = me(); $w = (int)($_GET['with'] ?? 0); $a = (int)($_GET['after'] ?? 0);
        $s = $pdo->prepare('SELECT id,from_id,body FROM messages WHERE id>? AND ((from_id=? AND to_id=?) OR (from_id=? AND to_id=?)) ORDER BY id LIMIT 100');
        $s->execute([$a, $u['id'], $w, $w, $u['id']]);
        $m = $s->fetchAll();
        $o = $pdo->prepare('SELECT (last_seen > NOW() - INTERVAL 20 SECOND) FROM users WHERE id=?'); $o->execute([$w]);
        out(['messages' => $m, 'online' => (bool)$o->fetchColumn()]);
    case 'call_start':
        $u = me(); $to = (int)($in['to_id'] ?? 0); $v = !empty($in['video']) ? 1 : 0;
        $s = $pdo->prepare('SELECT (last_seen > NOW() - INTERVAL 20 SECOND) FROM users WHERE id=?'); $s->execute([$to]);
        $on = $s->fetchColumn();
        if ($on === false) out(['ok' => false, 'error' => 'Unknown user']);
        if (!$on) out(['ok' => false, 'error' => 'User is offline']);
        $b = $pdo->prepare("SELECT id FROM calls WHERE callee_id=? AND status='ringing' AND created_at > NOW() - INTERVAL 40 SECOND LIMIT 1");
        $b->execute([$to]);
        if ($b->fetch()) out(['ok' => false, 'error' => 'User is busy']);
        $ch = bin2hex(random_bytes(8));
        $pdo->prepare("INSERT INTO calls(caller_id,callee_id,video,status,channel) VALUES(?,?,?,'ringing',?)")->execute([$u['id'], $to, $v, $ch]);
        out(['ok' => true, 'call_id' => (int)$pdo->lastInsertId(), 'channel' => $ch]);
    case 'call_poll':
        $u = me();
        $s = $pdo->prepare("SELECT c.id,c.caller_id AS from_id,c.video,c.channel,u.name,u.phone FROM calls c JOIN users u ON u.id=c.caller_id WHERE c.callee_id=? AND c.status='ringing' AND c.created_at > NOW() - INTERVAL 40 SECOND ORDER BY c.id DESC LIMIT 1");
        $s->execute([$u['id']]);
        out(['incoming' => $s->fetch() ?: null]);
    case 'call_status':
        $u = me(); $id = (int)($_GET['id'] ?? 0);
        $pdo->prepare("UPDATE calls SET status='missed', ended_at=NOW() WHERE id=? AND status='ringing' AND created_at < NOW() - INTERVAL 40 SECOND")->execute([$id]);
        // end the call if the other person has vanished (app closed / no network)
        $pdo->prepare("UPDATE calls SET status='ended', ended_at=NOW() WHERE id=? AND status='accepted' AND ((caller_id=? AND callee_id IN (SELECT id FROM users WHERE last_seen < NOW() - INTERVAL 30 SECOND)) OR (callee_id=? AND caller_id IN (SELECT id FROM users WHERE last_seen < NOW() - INTERVAL 30 SECOND)))")->execute([$id, $u['id'], $u['id']]);
        $s = $pdo->prepare('SELECT status FROM calls WHERE id=? AND (caller_id=? OR callee_id=?)'); $s->execute([$id, $u['id'], $u['id']]);
        out(['status' => $s->fetchColumn() ?: 'ended']);
    case 'call_answer':
        $u = me(); $id = (int)($in['id'] ?? 0); $act = $in['action'] ?? '';
        if ($act === 'accept') $q = "UPDATE calls SET status='accepted', answered_at=NOW() WHERE id=? AND callee_id=? AND status='ringing'";
        elseif ($act === 'decline') $q = "UPDATE calls SET status='declined', ended_at=NOW() WHERE id=? AND callee_id=? AND status='ringing'";
        elseif ($act === 'end') $q = "UPDATE calls SET status=IF(status='accepted','ended','missed'), ended_at=NOW() WHERE id=? AND (caller_id=? OR callee_id=?) AND status IN ('ringing','accepted')";
        else out(['error' => 'Invalid action'], 422);
        $st = $pdo->prepare($q); $st->execute($act === 'end' ? [$id, $u['id'], $u['id']] : [$id, $u['id']]);
        out(['ok' => $st->rowCount() > 0]);
    default:
        out(['error' => 'not found'], 404);
}
