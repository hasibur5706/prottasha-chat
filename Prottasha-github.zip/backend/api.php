<?php
// Upload to public_html/api/api.php, then fill in the 4 values below (from hPanel > Databases).
header('Content-Type: application/json; charset=utf-8');
$cfg = ['host' => 'localhost', 'db' => 'u000000000_pulsechat', 'user' => 'u000000000_pulse', 'pass' => 'CHANGE_ME'];
try {
    $pdo = new PDO("mysql:host={$cfg['host']};dbname={$cfg['db']};charset=utf8mb4", $cfg['user'], $cfg['pass'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]);
} catch (Throwable $e) { http_response_code(500); exit('{"error":"Database connection failed"}'); }

$in = json_decode(file_get_contents('php://input'), true) ?: [];
function out($d, $c = 200) { http_response_code($c); echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; }
function me() {
    global $pdo;
    $t = $_SERVER['HTTP_X_TOKEN'] ?? '';
    if (!preg_match('/^[a-f0-9]{64}$/', $t)) out(['error' => 'unauthorized'], 401);
    $s = $pdo->prepare('SELECT id,name,phone FROM users WHERE token_hash=?');
    $s->execute([hash('sha256', $t)]);
    $u = $s->fetch() ?: out(['error' => 'unauthorized'], 401);
    $pdo->prepare('UPDATE users SET last_seen=NOW() WHERE id=?')->execute([$u['id']]);   // presence heartbeat
    return $u;
}

function base() { return 'https://' . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/'); }

switch ($_GET['r'] ?? '') {
    case 'register':
        $n = trim($in['name'] ?? ''); $p = preg_replace('/\D/', '', $in['phone'] ?? ''); $pw = (string)($in['password'] ?? '');
        if (mb_strlen($n) < 2 || mb_strlen($n) > 30 || strlen($p) < 8 || strlen($p) > 15) out(['error' => 'Invalid name or phone number'], 422);
        if (strlen($pw) < 6) out(['error' => 'Password must be at least 6 characters'], 422);
        $t = bin2hex(random_bytes(32)); $h = password_hash($pw, PASSWORD_DEFAULT);
        // an older account without a password can be claimed by setting one
        $c = $pdo->prepare('UPDATE users SET name=?, password_hash=?, token_hash=? WHERE phone=? AND password_hash IS NULL');
        $c->execute([$n, $h, hash('sha256', $t), $p]);
        if ($c->rowCount() > 0) { $q = $pdo->prepare('SELECT id FROM users WHERE phone=?'); $q->execute([$p]); out(['ok' => true, 'id' => (int)$q->fetchColumn(), 'name' => $n, 'token' => $t]); }
        try { $pdo->prepare('INSERT INTO users(name,phone,password_hash,token_hash) VALUES(?,?,?,?)')->execute([$n, $p, $h, hash('sha256', $t)]); }
        catch (PDOException $e) { out(['error' => 'This number is already registered. Please log in.'], 409); }
        out(['ok' => true, 'id' => (int)$pdo->lastInsertId(), 'name' => $n, 'token' => $t]);
    case 'login':
        $p = preg_replace('/\D/', '', $in['phone'] ?? ''); $pw = (string)($in['password'] ?? '');
        $s2 = $pdo->prepare('SELECT id,name,password_hash FROM users WHERE phone=?'); $s2->execute([$p]); $r2 = $s2->fetch();
        if (!$r2 || !$r2['password_hash'] || !password_verify($pw, $r2['password_hash'])) out(['ok' => false, 'error' => 'Wrong phone number or password'], 401);
        $t = bin2hex(random_bytes(32));
        $pdo->prepare('UPDATE users SET token_hash=? WHERE id=?')->execute([hash('sha256', $t), $r2['id']]);
        out(['ok' => true, 'id' => (int)$r2['id'], 'name' => $r2['name'], 'token' => $t]);
    case 'upload':
        $u = me(); $f = $_FILES['file'] ?? null;
        if (!$f || $f['error'] !== UPLOAD_ERR_OK) out(['error' => 'Upload failed'], 422);
        if ($f['size'] > 25 * 1024 * 1024) out(['error' => 'File too large (max 25 MB)'], 413);
        $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg','jpeg','png','gif','webp','pdf','doc','docx','xls','xlsx','ppt','pptx','txt','zip','mp3','m4a','aac','ogg','mp4','3gp'], true)) out(['error' => 'File type not allowed'], 422);
        $dir = __DIR__ . '/uploads';
        if (!is_dir($dir)) { mkdir($dir, 0755); file_put_contents("$dir/.htaccess", "Options -Indexes\n"); }
        $name = bin2hex(random_bytes(12)) . '.' . $ext;
        if (!move_uploaded_file($f['tmp_name'], "$dir/$name")) out(['error' => 'Could not save file'], 500);
        out(['ok' => true, 'url' => base() . "/uploads/$name", 'name' => mb_substr(basename($f['name']), 0, 120), 'size' => (int)$f['size']]);
    case 'users':
        $u = me(); $i = $u['id'];
        $pv = "CASE m.type WHEN 'text' THEN m.body WHEN 'image' THEN 'Photo' WHEN 'voice' THEN 'Voice message' ELSE 'File' END";
        $s = $pdo->prepare("SELECT x.id,x.name,x.phone,(x.last_seen > NOW() - INTERVAL 20 SECOND) AS online,
          (SELECT $pv FROM messages m WHERE (m.from_id=x.id AND m.to_id=?) OR (m.from_id=? AND m.to_id=x.id) ORDER BY m.id DESC LIMIT 1) AS last,
          (SELECT UNIX_TIMESTAMP(m.created_at) FROM messages m WHERE (m.from_id=x.id AND m.to_id=?) OR (m.from_id=? AND m.to_id=x.id) ORDER BY m.id DESC LIMIT 1) AS last_ts,
          (SELECT COUNT(*) FROM messages m WHERE m.from_id=x.id AND m.to_id=? AND m.read_at IS NULL) AS unread
          FROM users x WHERE x.id<>? AND (x.id IN (SELECT contact_id FROM contacts WHERE owner_id=?) OR x.id IN (SELECT from_id FROM messages WHERE to_id=?))
          ORDER BY (last_ts IS NULL), last_ts DESC, x.name LIMIT 500");
        $s->execute([$i, $i, $i, $i, $i, $i, $i, $i]);
        $rows = $s->fetchAll(); foreach ($rows as &$x) $x['online'] = (bool)$x['online'];
        out(['users' => $rows]);
    case 'lookup':
        $u = me(); $p = preg_replace('/\D/', '', $_GET['phone'] ?? '');
        $s = $pdo->prepare('SELECT id,name,phone FROM users WHERE phone=?'); $s->execute([$p]); $f = $s->fetch();
        if (!$f) out(['found' => false]);
        if ((int)$f['id'] === (int)$u['id']) out(['found' => false, 'error' => 'That is your own number']);
        out(['found' => true, 'id' => (int)$f['id'], 'name' => $f['name'], 'phone' => $f['phone']]);
    case 'addcontact':
        $u = me(); $c = (int)($in['contact_id'] ?? 0);
        if (!$c || $c === (int)$u['id']) out(['error' => 'Invalid contact'], 422);
        try { $pdo->prepare('INSERT IGNORE INTO contacts(owner_id,contact_id) VALUES(?,?)')->execute([$u['id'], $c]); }
        catch (PDOException $e) { out(['error' => 'Unknown user'], 422); }
        out(['ok' => true]);
    case 'send':
        $u = me(); $to = (int)($in['to_id'] ?? 0); $b = trim($in['body'] ?? ''); $t = $in['type'] ?? 'text';
        if (!in_array($t, ['text', 'image', 'file', 'voice'], true)) $t = 'text';
        $url = $t === 'text' ? null : (string)($in['file_url'] ?? '');
        if (!$to || mb_strlen($b) > 2000 || ($t === 'text' && $b === '') || ($t !== 'text' && strpos($url, base() . '/uploads/') !== 0)) out(['error' => 'Invalid message'], 422);
        try { $pdo->prepare('INSERT INTO messages(from_id,to_id,body,type,file_url,file_name,file_size,duration) VALUES(?,?,?,?,?,?,?,?)')
            ->execute([$u['id'], $to, $b, $t, $url, $t === 'text' ? null : mb_substr((string)($in['file_name'] ?? ''), 0, 120), (int)($in['file_size'] ?? 0), (int)($in['duration'] ?? 0)]); }
        catch (PDOException $e) { out(['error' => 'Unknown recipient'], 422); }
        out(['ok' => true, 'id' => (int)$pdo->lastInsertId()]);
    case 'messages':
        $u = me(); $w = (int)($_GET['with'] ?? 0); $a = (int)($_GET['after'] ?? 0);
        $pdo->prepare('UPDATE messages SET read_at=NOW() WHERE from_id=? AND to_id=? AND read_at IS NULL')->execute([$w, $u['id']]);
        $s = $pdo->prepare('SELECT id,from_id,body,type,file_url,file_name,file_size,duration,UNIX_TIMESTAMP(created_at) AS ts FROM messages WHERE id>? AND ((from_id=? AND to_id=?) OR (from_id=? AND to_id=?)) ORDER BY id LIMIT 100');
        $s->execute([$a, $u['id'], $w, $w, $u['id']]);
        $m = $s->fetchAll();
        $o = $pdo->prepare('SELECT (last_seen > NOW() - INTERVAL 20 SECOND) FROM users WHERE id=?'); $o->execute([$w]);
        $r = $pdo->prepare('SELECT COALESCE(MAX(id),0) FROM messages WHERE from_id=? AND to_id=? AND read_at IS NOT NULL'); $r->execute([$u['id'], $w]);
        out(['messages' => $m, 'online' => (bool)$o->fetchColumn(), 'peer_read_upto' => (int)$r->fetchColumn()]);
    case 'call_start':
        $u = me(); $to = (int)($in['to_id'] ?? 0); $v = !empty($in['video']) ? 1 : 0;
        $s = $pdo->prepare('SELECT (last_seen > NOW() - INTERVAL 20 SECOND) FROM users WHERE id=?'); $s->execute([$to]);
        $on = $s->fetchColumn();
        if ($on === false) out(['ok' => false, 'error' => 'Unknown user']);
        if (!$on) out(['ok' => false, 'error' => 'User is offline']);
        $b = $pdo->prepare("SELECT id FROM calls WHERE callee_id=? AND status='ringing' AND created_at > NOW() - INTERVAL 40 SECOND LIMIT 1");
        $b->execute([$to]);
        if ($b->fetch()) out(['ok' => false, 'error' => 'User is busy']);
        $ch = bin2hex(random_bytes(8));
        $pdo->prepare("INSERT INTO calls(caller_id,callee_id,video,status,channel) VALUES(?,?,?,'ringing',?)")->execute([$u['id'], $to, $v, $ch]);
        out(['ok' => true, 'call_id' => (int)$pdo->lastInsertId(), 'channel' => $ch]);
    case 'call_poll':
        $u = me();
        $s = $pdo->prepare("SELECT c.id,c.caller_id AS from_id,c.video,c.channel,u.name,u.phone FROM calls c JOIN users u ON u.id=c.caller_id WHERE c.callee_id=? AND c.status='ringing' AND c.created_at > NOW() - INTERVAL 40 SECOND ORDER BY c.id DESC LIMIT 1");
        $s->execute([$u['id']]);
        out(['incoming' => $s->fetch() ?: null]);
    case 'call_status':
        $u = me(); $id = (int)($_GET['id'] ?? 0);
        $pdo->prepare("UPDATE calls SET status='missed', ended_at=NOW() WHERE id=? AND status='ringing' AND created_at < NOW() - INTERVAL 40 SECOND")->execute([$id]);
        // end the call if the other person has vanished (app closed / no network)
        $pdo->prepare("UPDATE calls SET status='ended', ended_at=NOW() WHERE id=? AND status='accepted' AND ((caller_id=? AND callee_id IN (SELECT id FROM users WHERE last_seen < NOW() - INTERVAL 30 SECOND)) OR (callee_id=? AND caller_id IN (SELECT id FROM users WHERE last_seen < NOW() - INTERVAL 30 SECOND)))")->execute([$id, $u['id'], $u['id']]);
        $s = $pdo->prepare('SELECT status FROM calls WHERE id=? AND (caller_id=? OR callee_id=?)'); $s->execute([$id, $u['id'], $u['id']]);
        out(['status' => $s->fetchColumn() ?: 'ended']);
    case 'call_answer':
        $u = me(); $id = (int)($in['id'] ?? 0); $act = $in['action'] ?? '';
        if ($act === 'accept') $q = "UPDATE calls SET status='accepted', answered_at=NOW() WHERE id=? AND callee_id=? AND status='ringing'";
        elseif ($act === 'decline') $q = "UPDATE calls SET status='declined', ended_at=NOW() WHERE id=? AND callee_id=? AND status='ringing'";
        elseif ($act === 'end') $q = "UPDATE calls SET status=IF(status='accepted','ended','missed'), ended_at=NOW() WHERE id=? AND (caller_id=? OR callee_id=?) AND status IN ('ringing','accepted')";
        else out(['error' => 'Invalid action'], 422);
        $st = $pdo->prepare($q); $st->execute($act === 'end' ? [$id, $u['id'], $u['id']] : [$id, $u['id']]);
        out(['ok' => $st->rowCount() > 0]);
    default:
        out(['error' => 'not found'], 404);
}
