-- Run once in phpMyAdmin > SQL (login passwords, files, voice messages, read ticks)
ALTER TABLE users ADD COLUMN password_hash VARCHAR(255) NULL;
ALTER TABLE messages
  ADD COLUMN type VARCHAR(10) NOT NULL DEFAULT 'text',
  ADD COLUMN file_url VARCHAR(255) NULL,
  ADD COLUMN file_name VARCHAR(120) NULL,
  ADD COLUMN file_size INT NULL,
  ADD COLUMN duration INT NULL,
  ADD COLUMN read_at DATETIME NULL;
UPDATE messages SET read_at = NOW();
