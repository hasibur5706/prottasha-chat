-- Run this once in phpMyAdmin if you already imported schema.sql earlier
CREATE TABLE IF NOT EXISTS contacts (
  owner_id INT NOT NULL,
  contact_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (owner_id, contact_id),
  FOREIGN KEY (owner_id) REFERENCES users(id),
  FOREIGN KEY (contact_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
