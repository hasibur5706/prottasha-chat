-- Run once in phpMyAdmin > SQL (adds online status + call tracking)
ALTER TABLE users ADD COLUMN last_seen DATETIME NULL;

CREATE TABLE IF NOT EXISTS calls (
  id INT AUTO_INCREMENT PRIMARY KEY,
  caller_id INT NOT NULL,
  callee_id INT NOT NULL,
  video TINYINT(1) NOT NULL DEFAULT 0,
  status ENUM('ringing','accepted','declined','ended','missed') NOT NULL DEFAULT 'ringing',
  channel VARCHAR(40) NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  answered_at DATETIME NULL,
  ended_at DATETIME NULL,
  INDEX (callee_id, status, id),
  FOREIGN KEY (caller_id) REFERENCES users(id),
  FOREIGN KEY (callee_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
